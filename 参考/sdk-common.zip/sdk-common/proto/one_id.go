package proto

type SaveOneIDInfoReq struct {
	ShopBaseReq
	OneID        string `json:"one_id"`
	AppKey       string `json:"app_key"`
	BuyerOpenUID string `json:"buyer_open_uid"`
	BuyerNick    string `json:"buyer_nick"`
}

type SaveOneIDInfoResp struct {
}

type SaveBuyerNickInfoReq struct {
	ShopBaseReq
	AppKey       string `json:"app_key"`
	BuyerOpenUID string `json:"buyer_open_uid"`
	BuyerNick    string `json:"buyer_nick"`
}

type SaveBuyerNickInfoResp struct {
	OneID string `json:"one_id"`
}

type GetOneIDByBuyerNickReq struct {
	ShopBaseReq
	BuyerNick string `json:"buyer_nick" form:"buyer_nick"`
}

type GetOneIDByBuyerNickResp struct {
	OneID string `json:"one_id"`
}

type GetOneIDByOpenUIDReq struct {
	ShopBaseReq
	OpenUID string `json:"open_uid" form:"open_uid"`
}

type GetOneIDByOpenUIDResp struct {
	OneID string `json:"one_id"`
}

type GetBuyerNickByOneIDReq struct {
	ShopBaseReq
	OneID string `json:"one_id" form:"one_id"`
}

type GetBuyerNickByOneIDResp struct {
	BuyerNick string `json:"buyer_nick"`
}

type CheckWhiteListShopReq struct {
	ShopID     string `json:"shop_id"`
	PlatUserID string `json:"plat_user_id"`
}

type CheckWhiteListShopResp struct {
	IsWhiteList bool `json:"is_white_list"`
}

type OpenUIDByNickReq struct {
	ShopBaseReq
	BuyerNicks []string `json:"buyer_nicks"`
}

type OpenUIDByNickResp struct {
	OpenUIDs struct {
		OpenUIDInfo []struct {
			BuyerNick    string `json:"buyer_nick"`
			BuyerOpenUID string `json:"buyer_open_uid"`
		} `json:"open_uid_info"`
	} `json:"open_uids"`
}

type GetOpenUIDByOneIDReq struct {
	ShopBaseReq
	OneID  string `json:"one_id" form:"one_id"`
	AppKey string `json:"app_key" form:"app_key"`
}

type GetOpenUIDByOneIDResp struct {
	OpenUID string `json:"open_uid"`
}

type GetBuyerNickByBuyerIDReq struct {
	ShopBaseReq
	BuyerId string `json:"buyer_id" form:"buyer_id"`
}

type GetBuyerNickByBuyerIDResp struct {
	BuyerNick string `json:"buyer_nick"`
}
