package proto

import (
	"gitlab.xiaoduoai.com/ecrobot/robotserver/models"
)

// 平台响应结构定义
type CommonAPIRes struct {
	Result    int    `json:"result"`     // 返回码
	ErrorMsg  string `json:"error_msg"`  // 错误消息
	RequestID string `json:"request_id"` // 请求ID
}

// 获取订单详情请求
type TradeInfoReq struct {
	ShopBaseReq
	CommonBaseReq
	OrderId   int64  `json:"order_id" form:"order_id"`
	OrderIdV2 string `json:"order_id_v2" form:"order_id_v2"` // 有些平台订单id不全是整形，比如yz
}

type Item struct {
	ItemID      string  `json:"item_id,omitempty"`
	ItemName    string  `json:"item_name,omitempty"`
	SkuID       string  `json:"sku_id,omitempty"`
	SkuName     string  `json:"sku_name,omitempty"`
	Count       int64   `json:"count,omitempty"`
	OuterItemID string  `json:"outer_item_id,omitempty"`
	Price       float32 `json:"price,omitempty"`
	PicPath     string  `json:"pic_path,omitempty"`
}

type TbExt struct {
	Items []Item `json:"items,omitempty"`
}

type Logistics struct {
	OutSid      string `json:"out_sid,omitempty"`      //物流单id
	CompanyName string `json:"company_name,omitempty"` //物流公司
}

type Order struct {
	Platform      string          `json:"platform,omitempty"`
	OrderID       string          `json:"order_id,omitempty"`
	ShopID        string          `json:"shop_id,omitempty"`
	SellerID      string          `json:"seller_id,omitempty"`
	BuyerID       string          `json:"buyer_id,omitempty"`
	BuyerOpenID   string          `json:"buyer_open_id,omitempty"`
	RealBuyerNick string          `json:"real_buyer_nick,omitempty"`
	Payment       float64         `json:"payment,omitempty"`
	Currency      string          `json:"currency,omitempty"` // 货币
	TotalFee      int64           `json:"totalFee,omitempty"`
	Address       string          `json:"address,omitempty"`
	BuyerName     string          `json:"buyer_name,omitempty"` // 收货人姓名
	Mobile        string          `json:"mobile,omitempty"`     // 收货人手机号
	Province      string          `json:"province,omitempty"`   // 收件人省份。
	City          string          `json:"city,omitempty"`       // 收件人城市。
	District      string          `json:"district,omitempty"`   // 收件人区县。
	Town          string          `json:"town,omitempty"`       // 镇
	Street        string          `json:"street,omitempty"`     // 街道
	Status        string          `json:"status,omitempty"`
	Remark        string          `json:"remark,omitempty"`
	BuyerRemark   string          `json:"buyer_remark,omitempty"`
	SellerMemo    string          `json:"seller_memo,omitempty"`
	CreatedAt     int64           `json:"created_at,omitempty"`
	UpdatedAt     int64           `json:"updated_at,omitempty"`
	PayTime       int64           `json:"pay_time,omitempty"`
	ItemIDs       []string        `json:"item_ids,omitempty"`
	PayType       string          `json:"pay_type,omitempty"`
	PayNo         string          `json:"pay_no,omitempty"`
	TBExt         TbExt           `json:"tbext,omitempty"`
	Logistics     Logistics       `json:"logistics,omitempty"`
	LogisticsInfo []LogisticsInfo `json:"logistics_info,omitempty"`
	SubOrders     []SubOrder      `json:"sub_orders,omitempty"`
}

// 子订单
type SubOrder struct {
	Oid       string  `json:"oid"`             // 子订单id
	Status    string  `json:"status"`          // 子订单状态
	ItemsInfo []Item  `json:"items,omitempty"` // 子订单商品信息
	Payment   float32 `json:"payment"`         // 子订单实付金额
	Extra     string  `json:"extra,omitempty"` // 子订单额外信息
}

type LogisticsInfo struct {
	TrackingNo  string `json:"tracking_no"`
	Company     string `json:"company"`
	DeliveryId  string `json:"delivery_id"`
	ShipTime    int64  `json:"ship_time"`
	CompanyName string `json:"company_name"`
}

// 获取订单详情结果
type TradeInfoRsp struct {
	Order
	ChildOrders []Order `json:"child_orders,omitempty"`
}

// 获取订单列表
type TradeListReq struct {
	TradeInfoReq
	Type        byte   `json:"type" form:"type"`
	CurrentPage int    `json:"current_page" form:"current_page"`
	PageSize    int    `json:"page_size" form:"page_size"`
	BeginTime   int64  `json:"begin_time" form:"begin_time"`
	EndTime     int64  `json:"end_time" form:"end_time"`
	Cursor      string `json:"cursor" form:"cursor"`
}

// 返回订单列表等数据到trade-sync
type TradeListRsp struct {
	// open 依赖，需要使用
	Items []models.ItemDetail `json:"item_detail"`

	// 新版本使用一下结构
	TotalPage int     `json:"total_page"`
	Cursor    string  `json:"Cursor"`
	Orders    []Order `json:"orderList"`
}

type TradeLogisticsCategoryReq struct {
	CommonBaseReq
	models.GetTradeLogisticsCategoryArgs
}
type TradeLogisticsCategoryRsp = models.GetTradeLogisticsCategoryReply

type TradeFullInfoReq struct {
	CommonBaseReq
	models.GetTradeInfoArgs
}
type TradeFullInfoRsp = models.GetTradeInfoReply
