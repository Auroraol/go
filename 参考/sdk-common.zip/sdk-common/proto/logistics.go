package proto

import "gitlab.xiaoduoai.com/ecrobot/robotserver/models"

type LogisticsInfoReq struct {
	CommonBaseReq
	models.GetOrderLogisticsArgs
}
type LogisticsInfoRsp = models.GetOrderLogisticsReply
