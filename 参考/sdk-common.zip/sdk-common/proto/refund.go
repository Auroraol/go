package proto

type RefundInfoReq struct {
	ShopBaseReq
	CommonBaseReq
	RefundID string `json:"refund_id"`
}

type RefundInfoRsp struct {
	Platform string
	Refund
}

type RefundListReq struct {
	ShopBaseReq
	CommonBaseReq
	OrderID  string `json:"order_id"`
	PageSize int64  `json:"page_size"`
	PageNo   int64  `json:"page_no"`
}

type RefundListRsp struct {
	Platform string   `json:"platform"`
	HasMore  bool     `json:"has_more"`
	Total    int64    `json:"total"`
	Refunds  []Refund `json:"refunds"`
}

type Refund struct {
	RefundID     string        `json:"refund_id"`
	RefundStatus string        `json:"refund_status"`
	RefundAmount float64       `json:"refund_amount"`
	BillType     string        `json:"bill_type"`
	ApplyTime    int64         `json:"apply_time"`
	UpdateTime   int64         `json:"update_time"`
	Reason       string        `json:"reason"`
	RefundItems  []*RefundItem `json:"refund_items"`
}

type RefundItem struct {
	ItemID   string `json:"item_id"`
	ItemName string `json:"item_name"`
	SkuID    string `json:"sku_id"`
	SkuName  string `json:"sku_name"`
	Count    int64  `json:"count"`
}
