package proto

type Empty struct {
}

type GetAuthLinkReq struct {
	CommonBaseReq
	State string `form:"state" json:"state"`
}

type GetAuthLinkRsp struct {
	AuthLink string `json:"auth_link,omitempty"`
}

// 验证授权码
type ValidateCodeReq struct {
	CommonBaseReq
	Code  string `form:"code" binding:"required"`
	State string `form:"state"`
}

// 验证授权码响应
type ValidateCodeRsp struct {
	PlatShopId   string `json:"plat_shop_id,omitempty"`   // 平台店铺ID。
	PlatShopName string `json:"plat_shop_name,omitempty"` // 平台店铺名。
	PlatUserId   string `json:"plat_user_id,omitempty"`   // 平台账号ID。
	PlatUserName string `json:"plat_user_name,omitempty"` // 平台账号名。
	PlatShopType string `json:"plat_shop_type"`           // 店铺类型
	OpenId       string `json:"open_id"`                  // 平台传递的open_id，应用唯一，不具有可读性
}

// 验证是否授权
type IsAuthorizedReq struct {
	ShopBaseReq
	CommonBaseReq
}

// 验证是否授权响应
type IsAuthorizedRsp struct {
	IsAuthorized bool  `json:"is_authorized"`
	ExpireTime   int64 `json:"expire_time"`
}

// token是否过期
type TokenValidReq struct {
	ShopBaseReq
	CommonBaseReq
}

// token是否过期响应
type TokenValidRsp struct {
	IsValid     bool   `json:"is_valid"`
	ExpireAt    int64  `json:"expire_at"`
	AccessToken string `json:"access_token"`
}
