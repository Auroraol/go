package proto

import (
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/token"
	"gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"
)

const (
	EApiNoImpl               = xd_error.ErrorCodeBaseSdkCommon + 1
	EApiNoShop               = xd_error.ErrorCodeBaseSdkCommon + 2
	EApiGetAccessTokenFailed = xd_error.ErrorCodeBaseSdkCommon + 3
	EApiCallApiFailed        = xd_error.ErrorCodeBaseSdkCommon + 4
	EApiGateWrongParam       = xd_error.ErrorCodeBaseSdkCommon + 5

	ETokenSaveFailed = token.ETokenSaveFailed
	ETokenLoadFailed = token.ETokenLoadFailed
	ETokenNotExists  = token.ETokenNotExists

	EWrongParam  = xd_error.ErrorCodeBaseSdkCommon + 1000
	ESystemError = xd_error.ErrorCodeBaseSdkCommon + 1001

	ESDKMainAccountNotExist = xd_error.ErrorCodeBaseSdkCommon + 2000

	ESDKGoodsNotExist = xd_error.ErrorCodeBaseSdkCommon + 3000

	// ErrSdkOrderNotFound  sdk查询不到订单
	ErrSdkOrderNotFound = "sdk_order_not_found"
)
