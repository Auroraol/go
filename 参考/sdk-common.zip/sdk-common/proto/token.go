package proto

import "gitlab.xiaoduoai.com/ecrobot/sdk-common/component/token"

type GetTokenReq struct {
	ShopBaseReq
	CommonBaseReq
}

type GetTokenRsp struct {
	token.IToken `json:"IToken"`
}

type GetTokenRspV2 struct {
	Token *token.TokenBase `json:"IToken"`
}
