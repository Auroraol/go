package proto

type MarketOrderInfoReq struct {
	CommonBaseReq
	OrderId string      `json:"order_id" form:"order_id" mapstructure:"order_id"`
	Ext     interface{} `json:"ext" form:"ext" mapstructure:"ext"`
}

type MarketOrderInfoRsp struct {
	IsBuyComplete      bool   `json:"is_buy_complete" form:"is_buy_complete"`
	PlatUserId         string `json:"plat_user_id" form:"plat_user_id"`
	ServiceLevel       int    `json:"service_level" form:"service_level"`
	FlowCount          int64  `json:"flow_count" form:"flow_count"`
	ExpireTime         int64  `json:"expire_time" form:"expire_time"`
	CurOrderTimeLength int64  `json:"cur_order_time_length" form:"cur_order_time_length"` // 当前订单的续订时长
}
