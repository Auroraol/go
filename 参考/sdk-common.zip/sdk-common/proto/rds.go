package proto

type RdsAddShopReq struct {
	AppName      string   `json:"app_name" form:"app_name"`            // 应用名称
	BusinessName string   `json:"business_name" form:"business_name"`  // 商业名称
	PlatUserID   []string `json:"plat_user_id" form:"plat_user_id"`    // 平台用户 ID 列表
}


type RdsAddShopRsp struct {
	Code  string `json:"code"`
	Message string `json:"message"`
}

type  RdsDelShopReq struct {
	AppName      string   `json:"app_name" form:"app_name"`            // 应用名称
	PlatUserID   []string `json:"plat_user_id" form:"plat_user_id"`    // 平台用户 ID 列表
}

type RdsDelShopRsp struct {
	Code  string `json:"code"`
	Message string `json:"message"`
}

type RdsListShopReq struct {
	AppName      string   `json:"app_name" form:"app_name"`            // 应用名称
	BusinessName string `json:"business_name" form:"business_name"`    // 用于区分业务

}

type RdsListShopRsp struct {

}