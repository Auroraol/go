package proto

type GetShopCategoryInfoReq struct {
	CommonBaseReq
	PlatShopId string `json:"plat_shop_id"`
	ShopId     string `json:"shop_id"`
}

type GetShopCategoryInfoRsp struct {
	MainCategoryCode string `json:"main_category_code"`
}

type GetUserSubsReq struct {
	CommonBaseReq
	PlatShopId string `json:"plat_shop_id" form:"plat_shop_id"`
}

type SubAccountState int

const (
	SubAccountStateOK      SubAccountState = 1
	SubAccountStateDeleted                 = -1
	SubAccountStateFrozen                  = 2
)

type SimpleSubAccount struct {
	Subname  string          `json:"sub_name"`
	State    SubAccountState `json:"state"`
	SubId    int64           `json:"sub_id"`
	IsOnline int             `json:"is_online"`
}

type GetUserSubsRes struct {
	Data []SimpleSubAccount `json:"data"`
}

// 获取用户部门
type GetUserDepartmentsReq struct {
	CommonBaseReq
	PlatShopId string `json:"plat_shop_id" form:"plat_shop_id"`
}

type GetUserDepartmentsItem struct {
	DepartmentID   string `json:"department_id"`
	ParentID       string `json:"parent_id"`
	DepartmentName string `json:"department_name"`
	SubUserIds     struct {
		Number []int64 `json:"number,omitempty"`
	} `json:"sub_user_ids,omitempty"`
}

type GetUserDepartmentsRes struct {
	Departments []GetUserDepartmentsItem `json:"departments"`
}
