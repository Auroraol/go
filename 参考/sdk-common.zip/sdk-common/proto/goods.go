package proto

import (
	"gitlab.xiaoduoai.com/ecrobot/goods_center/component/spu"
)

type Imgs struct {
	Url string `json:"url"`
}

// 获取商品信息请求
type GetGoodsInfoReq struct {
	ShopBaseReq
	CommonBaseReq
	PlatGoodsId string `json:"plat_goods_id,omitempty" form:"plat_goods_id"`
}

// 获取商品信息响应消息。
type GetGoodsInfoRsp struct {
	spu.Spu
	PlatCName string `json:"plat_cname"`
}

// 获取商品列表请求
type GetGoodsListReq struct {
	ShopBaseReq
	CommonBaseReq
	Page      int    `json:"page" form:"page"`             // 请求页码
	PageSize  int    `json:"page_size" form:"page_size"`   // 每页数量
	StartTime string `json:"start_time" form:"start_time"` // 开始时间
	EndTime   string `json:"end_time" form:"end_time"`     // 结束时间
	UseCursor bool   `json:"use_cursor" form:"use_cursor"` // 是否使用游标
	CursorID  string `json:"cursor_id" form:"cursor_id"`   // 游标ID
}

// 获取商品列表响应消息。
type GetGoodsListRsp struct {
	List     []GetGoodsInfoRsp `json:"list"`
	CursorID string            `json:"cursor_id"`
	// 总共的商品数量
	Total int64 `json:"total"`
}

// 获取类目信息
type GetGoodsCategoryInfoReq struct {
	ShopBaseReq
	CommonBaseReq
	Cids string `json:"cids" form:"cids"`
}

type CatInfoItem struct {
	Cid   string `json:"cid"`
	CName string `json:"name"`
}

type GetGoodsCategoryInfoRsp struct {
	CatInfo []CatInfoItem `json:"cats"`
}

type ParseGoodsIdReq struct {
	CommonBaseReq
	ShopId string `json:"shop_id" form:"shop_id"`
	Link   string `json:"link" form:"link"`
}

type ParseGoodsIdRsp struct {
	GoodsId string `json:"goods_id"`
}

type GetGoodsDetailImgReq struct {
	CommonBaseReq
	ShopBaseReq
	PlatGoodsID string `json:"goods_id" form:"goods_id"`
}

type GetGoodsDetailImgRsp struct {
	ImgList []Imgs `json:"img_list"`
}
