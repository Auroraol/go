package token

import (
	"strings"
)

var PrefixMap map[string]string

func NormKey(name, key string) string {
	Prefix, ok := PrefixMap[name]
	if !ok {
		Prefix = PrefixMap[DefaultTokenName]
	}
	if strings.HasPrefix(key, Prefix) {
		return key
	}
	return Prefix + key
}

func LockKey(name, key string) string {
	return NormKey(name, key) + "_lock"
}

func InitPrefix(name, value string) {
	if PrefixMap == nil {
		PrefixMap = make(map[string]string)
	}
	PrefixMap[name] = value
}
func InitDefaultPrefix(value string) {
	if PrefixMap == nil {
		PrefixMap = make(map[string]string)
	}
	PrefixMap[DefaultTokenName] = value
}
