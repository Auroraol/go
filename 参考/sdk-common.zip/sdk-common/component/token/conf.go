package token

import (
	//OCConf "gitlab.xiaoduoai.com/golib/octrace/config"
	"time"

	"gitlab.xiaoduoai.com/golib/xd_sdk/redisc"
)

type Config struct {
	// token 刷新配置
	Redis redisc.Config `mapstructure:"redis"`
	//OCTrace OCConf.Config `mapstructure:"oc_trace"`
	Prefix string `mapstructure:"prefix"`
	// app 对应配置
	Timeout         time.Duration `mapstructure:"timeout"`
	TokenRefreshIV  int64         `mapstructure:"token_refresh_interval"`
	ApiURI          string        `mapstructure:"api_uri"`
	AppName         string        `mapstructure:"app_name"`
	AppId           string        `mapstructure:"app_id"`
	AppSecret       string        `mapstructure:"app_secret"`
	CallbackURI     string        `mapstructure:"callback_uri"`
	AuthURI         string        `mapstructure:"auth_uri"`
	GetTokenURI     string        `mapstructure:"get_token_uri"`
	RefreshTokenURI string        `mapstructure:"refresh_token_uri"`
	IsDefault       bool          `mapstructure:"is_default"`
	//IsTestEnv        bool            `mapstructure:"is_test_env"`
	//AnswerFromKsTest bool            `mapstructure:"answer_from_ks_test"`
}

// ConfigMap 支持多应用
type ConfigMap map[string]Config
