package token

import (
	"context"
	"encoding/json"
	"time"
)

type TokenNewFunc func() IToken

type IToken interface {
	Key() string
	Data() []byte
	IsExpired(current int64) bool
	ShouldRefresh(ctx context.Context, current int64) bool
	IsValid() bool
	Refresh(ctx context.Context, current int64, appName string) int
	GetAccessToken() string
	GetRefreshToken() string
	GetExpiredTime() int64
	SetAppName(appName string)
	GetAppName() string
}

type TokenBase struct {
	PlatShopID   string `json:"plat_shop_id"`
	PlatShopName string `json:"plat_shop_name"`
	PlatUserID   string `json:"plat_user_id"`
	PlatUserName string `json:"plat_user_name"`
	State        string `json:"state"`
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	CreateTime   int64  `json:"create_time"`
	ExpireTime   int64  `json:"expire_time"`
	AppName      string `json:"app_name"`
}

func (t *TokenBase) Key() string {
	return NormKey(t.AppName, t.PlatUserID)
}

func (t *TokenBase) GetAccessToken() string {
	return t.AccessToken
}

func (t *TokenBase) GetRefreshToken() string {
	return t.RefreshToken
}

func (t *TokenBase) Data() []byte {
	data, _ := json.Marshal(t)
	return data
}

func (t *TokenBase) IsExpired(current int64) bool {
	return current >= t.ExpireTime
}

func (t *TokenBase) ShouldRefresh(ctx context.Context, current int64) bool {
	return current >= (t.ExpireTime+t.CreateTime)/2
}

func (t *TokenBase) IsValid() bool {
	return t.AccessToken != "" && time.Now().Before(time.Unix(t.ExpireTime, 0)) && t.RefreshToken != ""
}

func (t *TokenBase) Refresh(ctx context.Context, current int64, appName string) int {
	panic("please apply IToken.Refresh impl")
}

func (t *TokenBase) GetExpiredTime() int64 {
	return t.ExpireTime
}

func (t *TokenBase) SetAppName(appName string) {
	t.AppName = appName
}

func (t *TokenBase) GetAppName() string {
	return t.AppName
}
