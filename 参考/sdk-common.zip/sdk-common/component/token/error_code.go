package token

import "gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"

const (
	ETokenSaveFailed = xd_error.ErrorCodeBaseSdkCommon + 100
	ETokenLoadFailed = xd_error.ErrorCodeBaseSdkCommon + 101
	ETokenNotExists  = xd_error.ErrorCodeBaseSdkCommon + 102
)

const (
	TokenHandled   = 1
	TokenHandleErr = -1
	TokenSuccess   = 0
)
