package token

import (
	"context"
	"encoding/json"
	"fmt"
	"math/rand"
	"time"

	"github.com/gomodule/redigo/redis"
	"github.com/pkg/errors"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
	"gitlab.xiaoduoai.com/golib/xd_sdk/redisc"
	"gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"
)

var DefaultTokenName = "default"

type TokenMgr struct {
	Conf     *Config
	Name     string
	NewToken TokenNewFunc
}

var _defaultTokenMgr map[string]*TokenMgr

// Init
//
//	@Description: 初始化token管理程序
//	@param confMap  token配置文件
//	@param newTokenFunc  token生成函数
func Init(confMap ConfigMap, newTokenFunc TokenNewFunc) error {
	for name, conf := range confMap {
		if _defaultTokenMgr == nil {
			_defaultTokenMgr = make(map[string]*TokenMgr)
		}
		_defaultTokenMgr[name] = NewTokenMgr(conf, newTokenFunc, name)
		if conf.IsDefault {
			InitDefaultPrefix(conf.Prefix)
			_defaultTokenMgr[DefaultTokenName] = _defaultTokenMgr[name]
		}
		go _defaultTokenMgr[name].Run(context.Background())
	}
	if _defaultTokenMgr[DefaultTokenName] == nil {
		return fmt.Errorf("no default token")
	}
	return nil
}

func GetMgrInstance(name string) *TokenMgr {
	if name == "" {
		name = DefaultTokenName
	}
	return _defaultTokenMgr[name]
}

func NewTokenMgr(conf Config, newTokenFunc TokenNewFunc, name string) *TokenMgr {
	InitPrefix(name, conf.Prefix)
	if conf.TokenRefreshIV <= 0 {
		conf.TokenRefreshIV = 1200
	}
	return &TokenMgr{Conf: &conf, NewToken: newTokenFunc, Name: name}
}

func (mgr *TokenMgr) Run(ctx context.Context) error {
	for {
		select {
		case <-ctx.Done():
			return errors.Wrap(ctx.Err(), "daemon context done")
			//进入刷新函数的时间设为期的一半，函数内部随机sleep(0, iv/2)的时间，避免多个pod在相同的时间点刷新token导致报错
		case <-time.After(time.Second * time.Duration(mgr.Conf.TokenRefreshIV/2)):
			if err := mgr.RefreshTokens(ctx, mgr.Name); err != nil {
				logger.WithError(err).Errorf(ctx, "failed to refresh tokens")
			}
		}
	}
}

func (mgr *TokenMgr) RefreshTokens(ctx context.Context, name string) error {
	if !mgr.LockTokenKey(ctx) {
		logger.Warning(ctx, "有其他进程在刷新token")
		return nil
	}
	defer mgr.UnlockTokenKey(ctx)
	// 随机sleep (0-iv/2)的时间，避免多个pod同时刷新token
	rand.Seed(time.Now().Unix())
	time.Sleep(time.Second * time.Duration(rand.Int63n(mgr.Conf.TokenRefreshIV/2)))
	keys, err := mgr.LoadKeys(ctx, NormKey(name, "*"))
	if err != nil {
		return fmt.Errorf("failed to fetch keys: %v", err)
	}
	for _, key := range keys {
		t, err := mgr.LoadToken(ctx, key)
		if err != nil {
			logger.WithError(err).WithField("key", key).Errorf(ctx, "failed to load token")
			continue
		}
		t.SetAppName(name)
		logger.Debugf(ctx, "refresh key %s, at %s, rt %s", key, t.GetAccessToken(), t.GetRefreshToken())
		current := time.Now().Unix()
		if t.IsExpired(current) {
			if _, err = mgr.RedisC().DoWithContext(ctx, "DEL", t.Key()); err != nil {
				logger.WithError(err).Errorf(ctx, "failed to remove expired token(%+v)", t)
			} else {
				logger.Warningf(ctx, "already remove the expired token(%+v) from cache", t)
			}
			continue
		}
		if !t.ShouldRefresh(ctx, current) {
			continue
		}
		refreshRes := t.Refresh(ctx, current, name)
		if refreshRes != 0 {
			if refreshRes != TokenHandleErr {
				// 获取不成功，但是无需报错，比如两个pod同时刷新相同的token
				logger.Warningf(ctx, "token refresh is handle(%d) token(%+v)", refreshRes, t)
			} else {
				logger.Errorf(ctx, "token refresh failed, token(%+v)", t)
			}
			continue
		}
		if err := mgr.Save(ctx, t); err != nil {
			logger.Errorf(ctx, "token refresh save failed, token(%+v), err: %+v", t, err)
		}
	}
	return nil
}

func (mgr *TokenMgr) RedisC() redisc.Client {
	return mgr.Conf.Redis.Client
}

func (mgr *TokenMgr) Save(ctx context.Context, t IToken) error {
	logger.Debugf(ctx, "Save start %v,%s,%s", t, t.Key(), t.Data())
	reply, err := mgr.RedisC().DoWithContext(ctx, "SET", t.Key(), t.Data())
	logger.Debugf(ctx, "redis save reply:%v", reply)
	if err != nil {
		return xd_error.New(ETokenSaveFailed, err.Error())
	}
	logger.Debugf(ctx, "Save end ")
	return nil

}

func (mgr *TokenMgr) LoadToken(ctx context.Context, key string) (IToken, error) {
	data, err := redis.Bytes(mgr.RedisC().DoWithContext(ctx, "GET", NormKey(mgr.Name, key)))
	if err == redis.ErrNil {
		return nil, xd_error.New(ETokenNotExists, err.Error())
	}
	if err != nil {
		return nil, xd_error.New(ETokenLoadFailed, err.Error())
	}
	t := mgr.NewToken()
	if err = json.Unmarshal(data, t); err != nil {
		return nil, errors.Wrap(err, "failed to unmarshal data")
	}
	return t, nil
}

func (mgr *TokenMgr) LoadKeys(ctx context.Context, pattern string) (keys []string, err error) {
	cursor := 0
	for {
		reply, err := redis.Values(mgr.RedisC().DoWithContext(ctx, "SCAN", cursor, "MATCH", pattern, "COUNT", 1000))
		if err != nil {
			return keys, errors.Wrap(err, "failed to scan")
		}
		cursor, _ = redis.Int(reply[0], nil)
		k, _ := redis.Strings(reply[1], nil)
		keys = append(keys, k...)
		if cursor == 0 {
			break
		}
	}
	return keys, err
}

func (mgr *TokenMgr) LockTokenKey(ctx context.Context) bool {
	// 设置100秒过期，预防因为特殊情况导致的死锁不能刷新token
	res, err := mgr.RedisC().DoWithContext(ctx, "SET", LockKey(mgr.Name, mgr.Conf.Prefix), "1", "EX", 60*60, "NX")
	logger.Infof(ctx, "set nx res: %+v", res)
	if err != nil || res == nil {
		return false
	}
	return true
}

func (mgr *TokenMgr) UnlockTokenKey(ctx context.Context) {
	_, err := mgr.RedisC().DoWithContext(ctx, "DEL", LockKey(mgr.Name, mgr.Conf.Prefix))
	if err != nil {
		logger.Warningf(ctx, "unlock token error")
	}
}
