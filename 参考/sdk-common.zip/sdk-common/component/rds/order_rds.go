package rds

type IRDS interface {
	GetOrderDetail(tidStr string, mustHasFields []string, resPtr interface{}) error
	IsOpen() bool
	SetIsOpen(isOpen bool)
}

var gOrderRDS IRDS

func SetOrderRDS(orderRDS IRDS) {
	gOrderRDS = orderRDS
}

func GetOrderRDS() IRDS {
	return gOrderRDS
}
