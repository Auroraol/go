package rds

const (
	DY_METHOD   string = "dy"
)

type RdsConfig struct {
	RdsName  string `mapstructure:"rds_name"`
	Address  string `mapstructure:"address"`
	UserName string `mapstructure:"username"`
	Password string `mapstructure:"password"`
	DB       string `mapstructure:"db"`
	Table    string `mapstructure:"table"`
	IsOpen   bool   `mapstructure:"is_open"`
}

type Config struct {
	Rds []RdsConfig `mapstructure:"rds"`
}