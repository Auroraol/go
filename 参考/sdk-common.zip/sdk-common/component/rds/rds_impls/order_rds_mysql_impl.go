package rds_impls

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
	"gitlab.xiaoduoai.com/golib/xd_sdk/orm"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/rds"
)

type MysqlOrder struct {
	Config rds.MysqlConfig
	*gorm.DB
}

type MysqlOrderDetailRes struct {
	Response string `gorm:"column:ddp_response;type:longtext" json:"response"`  //API返回的整个JSON字符串，格式和API保持一致
}

type Recv struct {
	Response json.RawMessage `json:"response"`
}

func NewOrderRDSMysql(ctx context.Context, cfg *rds.MysqlConfig) (rds.IRDS, error) {
	if cfg == nil {
		return nil, errors.New("MysqlConfig nil")
	}

	newOne := MysqlOrder{}
	if !cfg.IsOpen {
		return &newOne, nil
	}

	mysqlSource := cfg.UserName + ":" + cfg.Password + "@" + cfg.Address + "/" +
		cfg.DB + "?charset=utf8"
	db, err := gorm.Open(mysql.Open(mysqlSource), &gorm.Config{})
	if err != nil {
		return nil, errors.New(fmt.Sprintf("init GoodsMysql failed(source: %s) err: %s", mysqlSource, err.Error()))
	}
	newOne.Config = *cfg
	newOne.DB = db
	logger.Infof(ctx, "connect to RDS mysql(%s) success", mysqlSource)
	return &newOne, nil
}

func NewOrderRDSMysql2(ctx context.Context, cfg *rds.MysqlConfig) (rds.IRDS, error) {
	if cfg == nil {
		return nil, errors.New("MysqlConfig nil")
	}

	newOne := MysqlOrder{}
	if !cfg.IsOpen {
		return &newOne, nil
	}

	mysqlSource := cfg.UserName + ":" + cfg.Password + "@" + cfg.Address + "/" +
		cfg.DB + "?charset=utf8"
	db, err := gorm.Open(mysql.Open(mysqlSource), &gorm.Config{})
	if err != nil {
		return nil, errors.New(fmt.Sprintf("init GoodsMysql failed(source: %s) err: %s", mysqlSource, err.Error()))
	}
	newOne.Config = *cfg
	newOne.DB = db
	logger.Infof(ctx, "connect to RDS mysql(%s) success", mysqlSource)
	return &newOne, nil
}


func (mt *MysqlOrder) GetOrderDetail(orderId string, mustHasFields []string, resPtr interface{}) error {
	if !mt.Config.IsOpen {
		return rds.ErrIsNotOpen
	}

	res := MysqlOrderDetailRes{}
	err := mt.DB.Table(mt.Config.Table).Where("order_id = ?", orderId).Select("ddp_response").Find(&res).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return rds.ErrNotFound
		}
		return err
	}

	recv := &Recv{}
	decoder := json.NewDecoder(strings.NewReader(res.Response))
	decoder.UseNumber()
	err = decoder.Decode(recv)
	if err != nil {
		return errors.New(fmt.Sprintf("Unmarshal recv failed: %s", err.Error()))
	}

	decoder = json.NewDecoder(bytes.NewReader(recv.Response))
	decoder.UseNumber()

	return decoder.Decode(resPtr)
}

func (mt *MysqlOrder) IsOpen() bool {
	return mt.Config.IsOpen
}

func (mt *MysqlOrder) SetIsOpen(isOpen bool) {
	mt.Config.IsOpen = isOpen
}





func (mt *MysqlOrder) GetOrderDetail2(orderId string)  {

	ctx := context.Background()
	opt := orm.Options{
		DBType: "postgres",
		Dsn:    "host=10.248.33.114 dbname=xdmp port=5433 user=goodscenter password=op1vsFOq6Ry&ZHt sslmode=disable TimeZone=Asia/Shanghai",
	}
	db, err := orm.NewClient(opt)
	if err != nil {
		panic(err)
	}
	gormDB := db.GetGormDB(ctx)

	res := MysqlOrderDetailRes{}
	err = gormDB.Table(mt.Config.Table).Where("order_id = ?", orderId).Select("ddp_response").Find(&res).Error
	if err != nil {
		panic(err)
	}
	fmt.Println("Found User:", res)
}
