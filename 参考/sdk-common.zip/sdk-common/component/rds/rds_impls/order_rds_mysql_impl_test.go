package rds_impls

import (
	"context"
	"fmt"
	"testing"

	"gitlab.xiaoduoai.com/golib/xd_sdk/orm"
)

type GetOrderInfoRes struct {
	Data struct {
		ShopOrderDetail OrderInfo `json:"shop_order_detail"`
	} `json:"data"`
}

type OrderInfo struct {
	OrderId             string           `json:"order_id"`
	OrderStatus         int              `json:"order_status"`
	OrderAmount         int              `json:"order_amount"`
	PayAmount           int              `json:"pay_amount"`
	BuyerWords          string           `json:"buyer_words"`
	ShopId              int              `json:"shop_id"`
	CreateTime          int64            `json:"create_time"`
	UpdateTime          int64            `json:"update_time"`
	PayTime             int64            `json:"pay_time"`
	//PostAddr            PostAddr         `json:"post_addr"`
	CancelReason        string           `json:"cancel_reason"`
	ExpShipTime         int64            `json:"exp_ship_time"`
	PayType             int              `json:"pay_type"`
	ChannelPaymentNo    string           `json:"channel_payment_no"`
	PostAmount          int              `json:"post_amount"`
	EncryptPostReceiver string           `json:"encrypt_post_receiver"`
	EncryptPostTel      string           `json:"encrypt_post_tel"`
	SellerWords         string           `json:"seller_words"`
	OpenId              string           `json:"open_id"`
	DoudianOpenId       string           `json:"doudian_open_id"`
	//Child               []ChildOrderInfo `json:"sku_order_list"`
	//LogisticsInfo       []LogisticsInfo  `json:"logistics_info"`
}


func TestGetOrderDetail(t *testing.T) {
	//ctx := context.Background()
	//cfg := &rds.MysqlConfig{
	//	IsOpen:   true,
	//	UserName: "testuser",
	//	Password: "testpassword",
	//	Address:  "localhost:3306",
	//	DB:       "testdb",
	//}
	//
	//var res GetOrderInfoRes
	//
	//mysqlOrder, err:= NewOrderRDSMysql(ctx, cfg)
	//err = mysqlOrder.GetOrderDetail("12345", []string{}, &res.Data.ShopOrderDetail)
	//if err != nil {
	//	t.Errorf("GetOrderDetail failed: %s", err)
	//}
	//t.Log(res)
}

type OrderDetailRes struct {
	Response string `gorm:"column:ddp_response;type:longtext" json:"response"`  //API返回的整个JSON字符串，格式和API保持一致
}

type UserMan struct {
	//ID        uint   `gorm:"primary_key"`
	//FirstName string `gorm:"size:255"`
	//LastName  string `gorm:"size:255"`
	Age       int    `gorm:"column:age;default:0"`
}


type RdsConfig struct {
	RdsName  string `mapstructure:"rds_name"`
	Address  string `mapstructure:"address"`  //私网或公网连接地址
	Port string  `mapstructure:"port"`  	  //端口号
	UserName string `mapstructure:"username"` //账号名称
	Password string `mapstructure:"password"` //账号密码
	DB       string `mapstructure:"db"`       //数据库名称
	DBType   string `mapstructure:"db_type"`  //数据库类型
	Table    string `mapstructure:"table"`    //表名
	IsOpen   bool   `mapstructure:"is_open"`
}

// GenerateDSN 生成 DSN 字符串
func (c *RdsConfig) GetDSN() string {
	return fmt.Sprintf(
		"host=%s port=%s dbname=%s user=%s password=%s sslmode=disable TimeZone=Asia/Shanghai",
		c.Address,
		c.Port,
		c.DB,
		c.UserName,
		c.Password,
	)
}

// 得到数据库类型
func (c *RdsConfig) GetDbType() string {
	return c.DBType
}




func TestName(t *testing.T) {
  conf	:= &RdsConfig{
	  Address:  "10.248.33.114",
	  Port:"5433",
	  DB:       "xdmp",
	  UserName: "goodscenter",
	  Password: "op1vsFOq6Ry&ZHt",
	  Table:    "users_man",
	  DBType:   "postgres",
	  IsOpen:   true,

	}

	ctx := context.Background()
	opt := orm.Options{
		DBType: conf.GetDbType(),
		Dsn:    conf.GetDSN(),
	}
	db, err := orm.NewClient(opt)
	if err != nil {
		panic(err)
	}
	gormDB := db.GetGormDB(ctx)

	res := UserMan{}
	err = gormDB.Table(conf.Table).Select("age").Find(&res).Error
	if err != nil {
		panic(err)
	}
	t.Log(res)
}