package conf_engine

import (
	"context"
	"errors"
	"fmt"
	"time"

	confSDK "gitlab.xiaoduoai.com/base/conf-engine/sdk"
)

const (
	namespace = "rs"
	appKey    = "sdk"
	confKey   = "rds"
)

type ShopIdGray struct {
	PlatUserIds    map[string]bool `json:"plat_user_ids" mapstructure:"plat_user_ids"`
	IsComplete bool            `json:"is_complete" mapstructure:"is_complete"`
}

func Init(ctx context.Context) error {
	confEngine := confSDK.GetInstance()
	if confEngine == nil {
		if err := confSDK.Init(ctx, confSDK.Config{
			Host:    "http://conf-engine-service:8080",
			Timeout: 10,
		}); err != nil {
			return fmt.Errorf("failed to initialize configuration engine: %w", err)
		}
		confEngine = confSDK.GetInstance()
	}

	if confEngine == nil {
		return fmt.Errorf("failed to initialize configuration engine")
	}
	return nil
}

// IsRdsWhiteListShop 获取店铺是否在白名单列表中
func  IsRdsWhiteListShop(ctx context.Context,platform  string,appName string, shopID string) (bool, error) {
	if platform == ""  || appName == "" || shopID == "" {
		return false, errors.New(" plat and appName and shopID must not be empty")
	}

	if err := Init(ctx); err != nil {
		return false, err
	}

	uid := fmt.Sprintf("%s_%s", platform, appName)

	conf, err := confSDK.GetInstance().GetConfData(ctx, namespace, appKey, confKey, uid, nil, 60*time.Second)
	if err != nil {
		return false, err
	}

	data := ShopIdGray{}
	if err := confSDK.Unmarshal(conf, &data); err != nil {
		return false, err
	}

	if data.IsComplete {
		return true, nil
	}

	if v, ok := data.PlatUserIds[shopID]; ok && v {



		return true, nil
		}

	return false, nil
}

// 设置店铺白名单
func SetWhiteShop(ctx context.Context,platform  string,appName string, shopID string,
	isWhite bool, isComplete bool) error {
	if err := Init(ctx); err != nil {
		return err
	}

	uid := fmt.Sprintf("%s_%s", platform, appName)

	// 初始化 plat_user_id
	platUserID := map[string]bool{
		shopID: isWhite,
	}

	// 构建 data
	data := map[string]interface{}{
		"plat_user_ids":  platUserID,
		"is_complete":   isComplete,
	}

	if err := confSDK.GetInstance().SetConfData(ctx, namespace, appKey, confKey, uid, data, true); err != nil {
		return err
	}

	return nil
}
//
//// 添加店铺白名单
//func  AddWhiteShop(ctx context.Context,appName string,shopID string) error {
//	if err := Init(ctx); err != nil {
//		return err
//	}
//
//	data := map[string]interface{}{
//		shopID: true,
//	}
//
//	if err := confSDK.GetInstance().SetConfData(ctx,  namespace, appKey, confKey, appName, data, true); err != nil {
//		return err
//	}
//
//	return nil
//}
//
//
//// 删除店铺白名单
//func  DeleteWhiteShop(ctx context.Context,appName string, shopID string) (err error) {
//	if err := Init(ctx); err != nil {
//		return err
//	}
//
//	data := map[string]interface{}{
//		shopID: false,
//	}
//
//	if err := confSDK.GetInstance().SetConfData(ctx,  namespace, appKey, confKey, appName, data, true); err != nil {
//		return err
//	}
//
//	return nil
//}
