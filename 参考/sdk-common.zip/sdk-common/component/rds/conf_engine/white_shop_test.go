package conf_engine

import (
	"fmt"
	"testing"

	"github.com/mitchellh/mapstructure"
)

type ShopIdGray1 struct {
	PlatUserIds    map[string]bool `json:"plat_user_ids" mapstructure:"plat_user_ids"`
	IsComplete bool            `json:"is_complete" mapstructure:"is_complete"`
}

func TestWhiteShop(t *testing.T) {
	//ctx := context.Background()

	// 初始化 plat_user_id
	platUserID := map[string]bool{
		"1111": true,
	}

	// 构建 data
	data := map[string]interface{}{
		"plat_user_ids":  platUserID,
		"is_complete":   false,
	}

	gray := ShopIdGray1{}
	t.Log(data)
	mapstructure.Decode(data,gray)
	fmt.Print(gray)
	//AddWhiteShop(ctx, "test", "test")
}
