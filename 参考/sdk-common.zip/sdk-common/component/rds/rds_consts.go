package rds

import "errors"

var ErrIsNotOpen = errors.New("RDS is not open")
var ErrNotFound = errors.New("RDS not found data")
var ErrNotSubscribe = errors.New("no subscribe rds")

type MysqlConfig struct {
	RdsName  string `toml:"rds_name"`
	Address  string `toml:"address"`
	UserName string `toml:"username"`
	Password string `toml:"password"`
	DB       string `toml:"db"`
	Table    string `toml:"table"`
	IsOpen   bool   `toml:"is_open"`
}
