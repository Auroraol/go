package sdkserver

import (
	"gitlab.xiaoduoai.com/ecrobot/goods_center/component/base/platform"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
	OCConf "gitlab.xiaoduoai.com/golib/xd_sdk/octrace/config"
)

type Config struct {
	HTTPListen  string             `mapstructure:"http_listen"`
	ProfPort    int                `mapstructure:"prof_port"`
	StdLog      logger.Options     `mapstructure:"std_log"`
	APILog      logger.Config      `mapstructure:"api_log"`
	OCTrace     OCConf.Config      `mapstructure:"oc_trace"`
	ServiceName string             `mapstructure:"service_name"`
	Platform    platform.TPlatform `mapstructure:"platform"`
	Gate        SdkGateOptions     `mapstructure:"sdk_gate"`
}

type SdkGateOptions struct {
	Addr    string `mapstructure:"url"`
	Timeout int64  `mapstructure:"timeout"`
}
