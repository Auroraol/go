package sdkserver

import (
	"context"
	httpmiddles "gitlab.xiaoduoai.com/golib/xd_sdk/httpserver/middles"
	"net/http"

	"net/http/httputil"
	"net/url"

	"github.com/gin-gonic/gin"
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/api"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpserver"
)

func routes(ctx context.Context, engine *gin.Engine, setter *api.ApiSetter, conf *Config) {

	api.RouteRegister(ctx,
		setter,
		func(uri string, hdl interface{}, opt ...httpmiddles.Option) {
			httpserver.Route(engine, http.MethodPost, uri, hdl, opt...)
			httpserver.Route(engine, http.MethodGet, uri, hdl, opt...)
		},
		func(uri string) {
			//proxy := engine.Group(uri)
			engine.Any(uri, func(ctx *gin.Context) {
				url_, err := url.Parse(conf.Gate.Addr)
				if err != nil {
					ctx.Writer.WriteString(err.Error())
					return
				}

				proxy := httputil.NewSingleHostReverseProxy(url_)
				proxy.Director = func(req *http.Request) {
					req.Header = ctx.Request.Header
					req.Host = url_.Host
					req.URL.Scheme = url_.Scheme
					req.URL.Host = url_.Host
					req.URL.Path = uri
				}

				proxy.ServeHTTP(ctx.Writer, ctx.Request)
			})
		},
	)
}
