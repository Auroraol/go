package sdkserver

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/pkg/errors"
	"github.com/urfave/cli"
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/api"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpserver"
	httpmiddles "gitlab.xiaoduoai.com/golib/xd_sdk/httpserver/middles"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
	"gitlab.xiaoduoai.com/golib/xd_sdk/octrace"
	"gitlab.xiaoduoai.com/golib/xd_sdk/runner"
	"gitlab.xiaoduoai.com/golib/xd_sdk/xdspec"
)

type Server struct {
	*cli.App
	config     *Config
	tasks      []runner.Task
	httpServer httpserver.Server
}

func NewServer(ctx context.Context, conf *Config, setter *api.ApiSetter, cbs ...callback) *Server {
	return newServer(ctx, conf, setter, cbs...)
}

type callback func(s *Server)

func newServer(ctx context.Context, conf *Config, setter *api.ApiSetter, cbs ...callback) *Server {
	s := &Server{App: cli.NewApp(), config: conf}
	s.Flags = []cli.Flag{cli.StringFlag{Name: "c", Usage: "Configuration file"}}
	s.Action = func(c *cli.Context) (err error) {

		if err := logger.ResetStandardWithOptions(conf.StdLog); err != nil {
			return errors.Wrap(err, "failed to set std logger")
		}

		// pprof
		xdspec.StartAdminOn(fmt.Sprintf(":%v", s.config.ProfPort))

		// trace
		flush, err := octrace.InitWithConfig(s.config.OCTrace, func(err error) {})
		if err != nil {
			return errors.Wrap(err, "failed to init trace")
		}
		defer flush()

		// init http
		httpServer := httpserver.NewServer(
			httpserver.WithAddress(s.config.HTTPListen),
			httpserver.WithEnableStats(true),
			httpserver.WithMiddles(
				//httpmiddles.LoggingRequestWithLogger(s.config.APILog), 日志缩减
				//httpmiddles.LoggingResponseWithLogger(s.config.APILog),日志缩减
				httpmiddles.Recovery(),
			),
		)
		s.httpServer = httpServer

		for _, cb := range cbs {
			cb(s)
		}

		// regitster http api hdls
		routes(ctx, httpServer.GetKernel(), setter, conf)

		s.tasks = append(s.tasks, httpServer)

		logger.Infof(ctx, "succeed to initialize server: config = %+v", *s.config)
		return runner.NewRunner(s.tasks...).Run(ctx)
	}
	return s
}

// WithGinRoute gin 的原生 route
func WithGinRoute(httpMethod, relativePath string, handlers ...gin.HandlerFunc) callback {
	return func(s *Server) {
		engine := s.httpServer.GetKernel()
		engine.Handle(httpMethod, relativePath, handlers...)
	}
}
