package id_map

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/gomodule/redigo/redis"

	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
)

// 管理open_id和plat_shop_id互相映射的关系，
// 在没有plat_shop_id的情况下会重新生成，目前只支持open_id生成plat_shop_id
type MapMgr struct {
	Conf   *Config
	Prefix string
}

var _defaultMapMgr *MapMgr

func Init(conf *Config) {
	_defaultMapMgr = &MapMgr{
		Conf:   conf,
		Prefix: "id_map_",
	}
}

func GetMgr() *MapMgr {
	return _defaultMapMgr
}

func (mgr *MapMgr) SaveMap(ctx context.Context, m *IdMap) error {
	err := mgr.CompletePlatShopId(ctx, m)
	if err != nil {
		logger.Errorf(ctx, "complete plat shop id err idMap(%v) err(%v)", m, err)
		return err
	}
	allMapKey := mgr.getAllMapKey(m)
	for _, key := range allMapKey {
		_, err := mgr.Conf.Redis.DoWithContext(ctx, "SET", key, m.Data())
		if err != nil {
			logger.Errorf(ctx, "%s key save to redis err %v id_map %v", key, err, m)
		}
	}
	return nil
}

// 不限制是什么id，因为key的组成规则是一样的
func (mgr *MapMgr) GetMapById(ctx context.Context, id string) (*IdMap, error) {
	key := mgr.genMapKey(id)
	b, err := redis.Bytes(mgr.Conf.Redis.Client.DoWithContext(ctx, "GET", key))
	if err != nil {
		return nil, err
	}
	res := &IdMap{}
	err = json.Unmarshal(b, res)
	if err != nil {
		return nil, err
	}
	return res, nil
}

func (mgr *MapMgr) CompletePlatShopId(ctx context.Context, m *IdMap) error {
	sessionMap, ok := mgr.CheckAndGetIdMap(ctx, m)
	if !ok {
		if m.PlatShopId == "" {
			platShopId, err := mgr.newPlatShopId(ctx)
			if err != nil {
				return err
			}
			m.PlatShopId = platShopId
			m.PlatUserId = platShopId
		}
	} else {
		m.PlatShopId = sessionMap.PlatShopId
		m.PlatUserId = sessionMap.PlatUserId
	}
	return nil
}

func (mgr *MapMgr) CheckAndGetIdMap(ctx context.Context, m *IdMap) (*IdMap, bool) {
	res, err := mgr.GetMapById(ctx, m.OpenId)
	if err == nil {
		return res, true
	}
	return nil, false
}

func (mgr *MapMgr) newPlatShopId(ctx context.Context) (string, error) {
	curDate := time.Now().Format("06102")
	count, err := redis.Int(mgr.Conf.Redis.DoWithContext(ctx, "INCR", curDate))
	if err != nil {
		return "", err
	}
	_, _ = mgr.Conf.Redis.DoWithContext(ctx, "EXPIRE", curDate, 24*60*60)
	return fmt.Sprintf("xd%s%d", curDate, count), nil
}

func (mgr *MapMgr) getAllMapKey(m *IdMap) []string {
	return []string{mgr.genMapKey(m.OpenId), mgr.genMapKey(m.PlatShopId)}
}

func (mgr *MapMgr) genMapKey(id string) string {
	return fmt.Sprintf("%s%s", mgr.Prefix, id)
}
