package id_map

import "gitlab.xiaoduoai.com/golib/xd_sdk/redisc"

type Config struct {
	Redis redisc.Config `mapstructure:"redis"`
}
