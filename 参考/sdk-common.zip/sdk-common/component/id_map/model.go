package id_map

import "encoding/json"

type IdMap struct {
	PlatShopId   string `json:"plat_shop_id"`
	PlatUserId   string `json:"plat_user_id"`
	PlatShopName string `json:"plat_shop_name"`
	PlatUserName string `json:"plat_user_name"`
	OpenId       string `json:"open_id"`
}

func (m *IdMap) Data() []byte {
	data, _ := json.Marshal(m)
	return data
}
