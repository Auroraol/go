package api

import (
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/app"
)

var _apiPrivilegesMap map[string]map[string][]app.TAppPri

func SetApiPrivileges(pf, api string, pris []app.TAppPri) {
	pfSetting, ok := _apiPrivilegesMap[pf]
	if !ok || pfSetting == nil {
		pfSetting = make(map[string][]app.TAppPri)
		_apiPrivilegesMap[pf] = pfSetting
	}
	pfSetting[api] = pris
}

func GetApiPrivileges(pf, api string) []app.TAppPri {
	pfSetting, ok := _apiPrivilegesMap[pf]
	if !ok || pfSetting == nil {
		return nil
	}
	apiPrivileges := pfSetting[api]
	return apiPrivileges
}

// tb api, todo: 移动到外部
func init() {
	_apiPrivilegesMap = make(map[string]map[string][]app.TAppPri)

	/*
		shop && seller
	*/
	// 权限包ID: 386
	SetApiPrivileges("tb", "taobao.shop.seller.get", []app.TAppPri{app.EPriShopInfo})
	SetApiPrivileges("tb", "taobao.shopcats.list.get", []app.TAppPri{app.EPriShopCats})
	SetApiPrivileges("tb", "taobao.sellercats.list.get", []app.TAppPri{app.EPriShopSellerCats})

	/*
		goods
	*/
	// 权限包ID: 12138
	SetApiPrivileges("tb", "taobao.item.seller.get", []app.TAppPri{app.EPriGoodsInfo})
	SetApiPrivileges("tb", "taobao.items.seller.list.get", []app.TAppPri{app.EPriGoodsBatchInfo, app.EPriGoodsInventoryGoodsInfo})
	// 权限包ID: 382
	SetApiPrivileges("tb", "taobao.items.onsale.get", []app.TAppPri{app.EPriGoodsOnsaleInfos})
	SetApiPrivileges("tb", "taobao.items.inventory.get", []app.TAppPri{app.EPriGoodsInventoryInfo})
	// 权限包ID: 383
	SetApiPrivileges("tb", "taobao.itemcats.get", []app.TAppPri{app.EPriGoodsCatsInfo})

	/*
		trade
	*/
	// 权限包ID: 12146
	SetApiPrivileges("tb", "taobao.trade.fullinfo.get", []app.TAppPri{app.EPriTradeOrderFullInfo})
	SetApiPrivileges("tb", "taobao.trades.sold.get", []app.TAppPri{app.EPriTradeSoldGet})
	SetApiPrivileges("tb", "taobao.trades.sold.increment.get", []app.TAppPri{app.EPriTradeIncrement})
	// 权限包ID: 12136
	SetApiPrivileges("tb", "taobao.traderates.get", []app.TAppPri{app.EPriTradeRate})

	/*
		refund
	*/
	// 权限包ID: 11850
	SetApiPrivileges("tb", "taobao.refund.get", []app.TAppPri{app.EPriTradeRefund})

	/*
		logistics
	*/
	// 权限包ID: 12141
	SetApiPrivileges("tb", "taobao.logistics.trace.search", []app.TAppPri{app.EPriLogisticsInfo})

	/*
		user
	*/
	// 权限包ID: 11852
	SetApiPrivileges("tb", "taobao.sellercenter.subusers.get", []app.TAppPri{app.EPriUserSubs})
	SetApiPrivileges("tb", "taobao.subuser.departments.get", []app.TAppPri{app.EPriUserDepartments})
	SetApiPrivileges("tb", "taobao.subuser.fullinfo.get", []app.TAppPri{app.EPriUserSubInfo})

	/*
		tmc
	*/
	// 权限包ID: 12159
	SetApiPrivileges("tb", "taobao.tmc.user.permit", []app.TAppPri{app.EpriTmcPermit})
	SetApiPrivileges("tb", "taobao.tmc.user.cancel", []app.TAppPri{app.EpriTmcCancel})
	SetApiPrivileges("tb", "taobao.tmc.group.add", []app.TAppPri{app.EpriTmcGroupAdd})
	SetApiPrivileges("tb", "taobao.tmc.group.delete", []app.TAppPri{app.EpriTmcGroupDelete})

	SetApiPrivileges("tb", "taobao.jushita.jms.user.add", []app.TAppPri{app.EpriMsgsyncUserAdd})
}
