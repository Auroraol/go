package api

import (
	"context"

	"gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"
)

var NotImplErr *xd_error.XDError = &xd_error.XDError{Code: proto.EApiNoImpl, Message: "no impl"}

type DefaultHdl struct {
}

func (hdl *DefaultHdl) GoodsInfoHdl() TGoodsInfoHdl {
	return func(ctx context.Context, req *proto.GetGoodsInfoReq, rsp *proto.GetGoodsInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GoodsListHdl() TGoodsListHdl {
	return func(ctx context.Context, req *proto.GetGoodsListReq, rsp *proto.GetGoodsListRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GoodsCatsHdl() TGoodsCatsHdl {
	return func(ctx context.Context, req *proto.GetGoodsCategoryInfoReq, rsp *proto.GetGoodsCategoryInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GoodsDetailImgHdl() TGoodsDetailImgHdl {
	return func(ctx context.Context, req *proto.GetGoodsDetailImgReq, rsp *proto.GetGoodsDetailImgRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) AuthLinkHdl() TAuthLinkHdl {
	return func(ctx context.Context, req *proto.GetAuthLinkReq, rsp *proto.GetAuthLinkRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) ValidateCodeHdl() TValidateCodeHdl {
	return func(ctx context.Context, req *proto.ValidateCodeReq, rsp *proto.ValidateCodeRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) IsAuthorizedHdl() TIsAuthorizedHdl {
	return func(ctx context.Context, req *proto.IsAuthorizedReq, rsp *proto.IsAuthorizedRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) IsTokenValidHdl() TIsTokenValidHdl {
	return func(ctx context.Context, req *proto.TokenValidReq, rsp *proto.TokenValidRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GateProxyHdl() TGateProxyHdl {
	return func(ctx context.Context, req *proto.Empty, rsp *proto.Empty) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetTokenHdl() TGetTokenHdl {
	return func(ctx context.Context, req *proto.Empty, rsp *proto.Empty) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetShopCategoryHdl() TGetShopCategoryHdl {
	return func(ctx context.Context, req *proto.GetShopCategoryInfoReq, rsp *proto.GetShopCategoryInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) ParseGoodsIdHdl() TParseGoodsIdHdl {
	return func(ctx context.Context, req *proto.ParseGoodsIdReq, rsp *proto.ParseGoodsIdRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) TradeInfoHdl() TTradeInfoHdl {
	return func(ctx context.Context, req *proto.TradeInfoReq, rsp *proto.TradeInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) TradeListHdl() TTradeListHdl {
	return func(ctx context.Context, req *proto.TradeListReq, rsp *proto.TradeListRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) TradeLogisticsCategoryHdl() TTradeLogisticsCategory {
	return func(ctx context.Context, req *proto.TradeLogisticsCategoryReq, rsp *proto.TradeLogisticsCategoryRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) TradeFullInfoHdl() TTradeFullInfo {
	return func(ctx context.Context, req *proto.TradeFullInfoReq, rsp *proto.TradeFullInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) LogisticsInfoHdl() TLogisticsInfo {
	return func(ctx context.Context, req *proto.LogisticsInfoReq, rsp *proto.LogisticsInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) RefundInfoHdl() TRefundInfoHdl {
	return func(ctx context.Context, req *proto.RefundInfoReq, rsp *proto.RefundInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) RefundListHdl() TRefundListHdl {
	return func(ctx context.Context, req *proto.RefundListReq, rsp *proto.RefundListRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) MarketOrderInfoHdl() TMarketOrderInfo {
	return func(ctx context.Context, req *proto.MarketOrderInfoReq, rsp *proto.MarketOrderInfoRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetUserSubsHdl() TGetUserSubsHdl {
	return func(ctx context.Context, req *proto.GetUserSubsReq, rsp *proto.GetUserSubsRes) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetUserDepartmentHdl() TGetUserDepartmentHdl {
	return func(ctx context.Context, req *proto.GetUserDepartmentsReq, rsp *proto.GetUserDepartmentsRes) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) SaveOneIDInfoHdl() TSaveOneIDInfoHdl {
	return func(ctx context.Context, req *proto.SaveOneIDInfoReq, rsp *proto.SaveOneIDInfoResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) BuyerNickSaveHdl() TBuyerNickSaveHdl {
	return func(ctx context.Context, req *proto.SaveBuyerNickInfoReq, rsp *proto.SaveBuyerNickInfoResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetByBuyerNickHdl() TGetByBuyerNickHdl {
	return func(ctx context.Context, req *proto.GetOneIDByBuyerNickReq, rsp *proto.GetOneIDByBuyerNickResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) GetByOpenUIDHdl() TGetByOpenUIDHdl {
	return func(ctx context.Context, req *proto.GetOneIDByOpenUIDReq, rsp *proto.GetOneIDByOpenUIDResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) BuyerNickGetByOneIDHdl() TBuyerNickGetByOneIDHdl {
	return func(ctx context.Context, req *proto.GetBuyerNickByOneIDReq, rsp *proto.GetBuyerNickByOneIDResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) CheckWhiteListShopHdl() TCheckWhiteListShopHdl {
	return func(ctx context.Context, req *proto.CheckWhiteListShopReq, rsp *proto.CheckWhiteListShopResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) OpenUIDGetByOneIDHdl() TOpenUIDGetByOneIDHdl {
	return func(ctx context.Context, req *proto.GetOpenUIDByOneIDReq, rsp *proto.GetOpenUIDByOneIDResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) OpenUIDGetByNickHdl() TOpenUIDGetByNickHdl {
	return func(ctx context.Context, req *proto.OpenUIDByNickReq, rsp *proto.OpenUIDByNickResp) error {
		return NotImplErr
	}
}
func (hdl *DefaultHdl) GetBuyerNickByBuyerIDHdl() TGetBuyerNickByBuyerIDHdl {
	return func(ctx context.Context, req *proto.GetBuyerNickByBuyerIDReq, rsp *proto.GetBuyerNickByBuyerIDResp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) RdsAddShopHdl() TRdsAddShopHdl {
	return func(ctx context.Context, req *proto.RdsAddShopReq, rsp *proto.RdsAddShopRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) RdsDelShopHdl() TRdsDelShopHdl {
	return func(ctx context.Context, req *proto.RdsDelShopReq, rsp *proto.RdsDelShopRsp) error {
		return NotImplErr
	}
}

func (hdl *DefaultHdl) RdsListShopHdl() TRdsListShopHdl {
	return func(ctx context.Context, req *proto.RdsListShopReq, rsp *proto.RdsListShopRsp) error {
		return NotImplErr
	}
}
