package api

import (
	"context"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"
)

// sdk hdls
type TGoodsInfoHdl func(ctx context.Context, req *proto.GetGoodsInfoReq, rsp *proto.GetGoodsInfoRsp) error
type TGoodsListHdl func(ctx context.Context, req *proto.GetGoodsListReq, rsp *proto.GetGoodsListRsp) error
type TGoodsCatsHdl func(ctx context.Context, req *proto.GetGoodsCategoryInfoReq, rsp *proto.GetGoodsCategoryInfoRsp) error
type TParseGoodsIdHdl func(ctx context.Context, req *proto.ParseGoodsIdReq, rsp *proto.ParseGoodsIdRsp) error
type TGoodsDetailImgHdl func(ctx context.Context, req *proto.GetGoodsDetailImgReq, rsp *proto.GetGoodsDetailImgRsp) error

type TAuthLinkHdl func(ctx context.Context, req *proto.GetAuthLinkReq, rsp *proto.GetAuthLinkRsp) error
type TValidateCodeHdl func(ctx context.Context, req *proto.ValidateCodeReq, rsp *proto.ValidateCodeRsp) error
type TIsAuthorizedHdl func(ctx context.Context, req *proto.IsAuthorizedReq, rsp *proto.IsAuthorizedRsp) error
type TIsTokenValidHdl func(ctx context.Context, req *proto.TokenValidReq, rsp *proto.TokenValidRsp) error

type TGetShopCategoryHdl func(ctx context.Context, req *proto.GetShopCategoryInfoReq, rsp *proto.GetShopCategoryInfoRsp) error
type TGetUserSubsHdl func(ctx context.Context, req *proto.GetUserSubsReq, rsp *proto.GetUserSubsRes) error
type TGetUserDepartmentHdl func(ctx context.Context, req *proto.GetUserDepartmentsReq, rsp *proto.GetUserDepartmentsRes) error

type TTradeInfoHdl func(ctx context.Context, req *proto.TradeInfoReq, rsp *proto.TradeInfoRsp) error
type TTradeListHdl func(ctx context.Context, req *proto.TradeListReq, rsp *proto.TradeListRsp) error
type TTradeLogisticsCategory func(ctx context.Context, req *proto.TradeLogisticsCategoryReq, rsp *proto.TradeLogisticsCategoryRsp) error
type TTradeFullInfo func(ctx context.Context, req *proto.TradeFullInfoReq, rsp *proto.TradeFullInfoRsp) error

type TLogisticsInfo func(ctx context.Context, req *proto.LogisticsInfoReq, rsp *proto.LogisticsInfoRsp) error

type TRefundInfoHdl func(ctx context.Context, req *proto.RefundInfoReq, rsp *proto.RefundInfoRsp) error

type TRefundListHdl func(ctx context.Context, req *proto.RefundListReq, rsp *proto.RefundListRsp) error

type TMarketOrderInfo func(ctx context.Context, req *proto.MarketOrderInfoReq, rsp *proto.MarketOrderInfoRsp) error

type TGetTokenHdl interface{}  // 这个东西太个性化了，自己怼吧
type TGateProxyHdl interface{} // 这个东西太个性化了，自己怼吧

type TGetTokenHdlV2 func(ctx context.Context, req *proto.GetTokenReq, rsp *proto.GetTokenRsp) error //v2版本尝试固定token方法模板

// one_id
type TSaveOneIDInfoHdl func(ctx context.Context, req *proto.SaveOneIDInfoReq, rsp *proto.SaveOneIDInfoResp) error
type TBuyerNickSaveHdl func(ctx context.Context, req *proto.SaveBuyerNickInfoReq, rsp *proto.SaveBuyerNickInfoResp) error
type TGetByBuyerNickHdl func(ctx context.Context, req *proto.GetOneIDByBuyerNickReq, rsp *proto.GetOneIDByBuyerNickResp) error
type TGetByOpenUIDHdl func(ctx context.Context, req *proto.GetOneIDByOpenUIDReq, rsp *proto.GetOneIDByOpenUIDResp) error
type TBuyerNickGetByOneIDHdl func(ctx context.Context, req *proto.GetBuyerNickByOneIDReq, rsp *proto.GetBuyerNickByOneIDResp) error
type TCheckWhiteListShopHdl func(ctx context.Context, req *proto.CheckWhiteListShopReq, rsp *proto.CheckWhiteListShopResp) error
type TOpenUIDGetByOneIDHdl func(ctx context.Context, req *proto.GetOpenUIDByOneIDReq, rsp *proto.GetOpenUIDByOneIDResp) error
type TOpenUIDGetByNickHdl func(ctx context.Context, req *proto.OpenUIDByNickReq, rsp *proto.OpenUIDByNickResp) error

type TGetBuyerNickByBuyerIDHdl func(ctx context.Context, req *proto.GetBuyerNickByBuyerIDReq, rsp *proto.GetBuyerNickByBuyerIDResp) error

type TRdsAddShopHdl func(ctx context.Context, req *proto.RdsAddShopReq, rsp *proto.RdsAddShopRsp) error
type TRdsDelShopHdl func(ctx context.Context, req *proto.RdsDelShopReq, rsp *proto.RdsDelShopRsp) error
type TRdsListShopHdl func(ctx context.Context, req *proto.RdsListShopReq, rsp *proto.RdsListShopRsp) error

type IHdl interface {
	// --- sdk api 接口 ---
	// 商品
	GoodsInfoHdl() TGoodsInfoHdl
	GoodsListHdl() TGoodsListHdl
	GoodsCatsHdl() TGoodsCatsHdl
	ParseGoodsIdHdl() TParseGoodsIdHdl
	GoodsDetailImgHdl() TGoodsDetailImgHdl
	// user
	GetShopCategoryHdl() TGetShopCategoryHdl
	GetUserSubsHdl() TGetUserSubsHdl
	GetUserDepartmentHdl() TGetUserDepartmentHdl

	// --- sdk gate 接口 ---
	// auth
	GetTokenHdl() TGetTokenHdl
	AuthLinkHdl() TAuthLinkHdl
	ValidateCodeHdl() TValidateCodeHdl
	IsAuthorizedHdl() TIsAuthorizedHdl
	IsTokenValidHdl() TIsTokenValidHdl

	// proxy
	GateProxyHdl() TGateProxyHdl

	//trade
	TradeInfoHdl() TTradeInfoHdl
	TradeListHdl() TTradeListHdl
	TradeLogisticsCategoryHdl() TTradeLogisticsCategory
	TradeFullInfoHdl() TTradeFullInfo

	//logistics
	LogisticsInfoHdl() TLogisticsInfo

	// refund
	RefundInfoHdl() TRefundInfoHdl
	RefundListHdl() TRefundListHdl

	// market
	MarketOrderInfoHdl() TMarketOrderInfo

	//one_id
	SaveOneIDInfoHdl() TSaveOneIDInfoHdl

	BuyerNickSaveHdl() TBuyerNickSaveHdl

	GetByBuyerNickHdl() TGetByBuyerNickHdl

	GetByOpenUIDHdl() TGetByOpenUIDHdl

	BuyerNickGetByOneIDHdl() TBuyerNickGetByOneIDHdl

	CheckWhiteListShopHdl() TCheckWhiteListShopHdl

	OpenUIDGetByOneIDHdl() TOpenUIDGetByOneIDHdl

	OpenUIDGetByNickHdl() TOpenUIDGetByNickHdl

	GetBuyerNickByBuyerIDHdl() TGetBuyerNickByBuyerIDHdl

	// rds
	RdsAddShopHdl() TRdsAddShopHdl
	RdsDelShopHdl() TRdsDelShopHdl
	RdsListShopHdl() TRdsListShopHdl

}
