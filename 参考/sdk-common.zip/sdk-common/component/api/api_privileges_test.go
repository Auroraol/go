package api

import (
	"testing"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/app"
)

func TestAppPickup(t *testing.T) {

	pris := GetApiPrivileges("tb", "taobao.refund.get")
	if pris[0] != app.EPriTradeRefund {
		t.Errorf("GetApiPrivileges failed")
	}
}
