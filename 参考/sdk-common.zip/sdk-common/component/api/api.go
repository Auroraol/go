package api

import (
	"context"

	httpmiddles "gitlab.xiaoduoai.com/golib/xd_sdk/httpserver/middles"

	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
)

// sdk uri s
// sdk对外通用的api定义
const (
	// 获取授权地址
	EURIAuthGetAuthAddr = "/sdk/auth/get_auth_address"
	// 授权回调接口
	EURIAuthValidateCode = "/sdk/auth/validate_code"
	// 是否授权
	EURIAuthIsAuthorized = "/sdk/auth/is_authorized"
	// token是否过期
	EURIAuthTokenValid = "/sdk/auth/token_valid"

	// 获取商品详情
	EURIGoodsInfo = "/sdk/goods/info"
	// 获取商品列表
	EURIGoodsList = "/sdk/goods/list"
	// 获取商品分类
	EURIGoodsCats = "/sdk/goods/cats"
	// 从商品链接中提取商品
	EURIParseGoodsId = "/sdk/goods/parse_link"
	// 获取商品详情页介绍图片
	EURIGoodsDetailImg = "/sdk/goods/detail_imgs"
	// 获取店铺类目详情
	EURIShopCategoryInfo = "/sdk/user/get_shop_category_info"
	// 获取子账号列表
	EURIGetUserSubs = "/sdk/user/subs"
	// 获取子账号部门信息
	EURIGetUserDepartment = "/sdk/user/departments"
	// token gate
	EURIGateProxy = "/sdk/gate"
	// 获取token详情
	EURITokenInfo = "/sdk/token"
	// 获取订单详情
	EURITradeInfo = "/sdk/trade/info"
	// 获取订单列表
	EURITradeList              = "/sdk/trade/order_list"
	EURITradeLogisticsCategory = "/sdk/trade/logistics_category"
	EURITradeFullInfo          = "/sdk/trade/fullinfo"
	// 获取订单物流详情
	EURILogisticsInfo = "/sdk/logistics/info"
	// 获取市场订单详情（店铺订购应用的订单）
	EURIRefundInfo = "/sdk/refund/info"
	EURIRefundList = "/sdk/refund/list"

	EURIMarketOrderDetail = "/sdk/market/order_info"

	//one_id
	EURIOneIdSaveOneIDInfo         = "/sdk/one_id/save"
	EURIOneIdBuyerNickSave         = "/sdk/one_id/buyer_nick/save"
	EURIOneIdGetByBuyerNick        = "/sdk/one_id/get_by_buyer_nick"
	EURIOneIdGetByOpenUID          = "/sdk/one_id/get_by_open_uid"
	EURIOneIdBuyerNickGetByOneID   = "/sdk/one_id/buyer_nick/get_by_one_id"
	EURIOneIdCheckWhiteListShop    = "/sdk/one_id/check_white_shop"
	EURIOneIdOpenUIDGetByOneID     = "/sdk/one_id/open_uid/get_by_one_id"
	EURIOneIdOpenUIDGetByNick      = "/sdk/one_id/open_uid/get_by_nick"
	EURIOneIdGetBuyerNickByBuyerID = "/sdk/one_id/buyer_nick/get_by_buyer_id"

	// TODO
	EURIRdsAddShop  = "/sdk/rds/plat_rds_bind_shop/add"  // 添加 RDS 数据推送店铺
	EURIRdsDelShop  = "/sdk/rds/plat_rds_bind_shop/del"  // 删除 RDS 数据推送店铺
	EURIRdsListShop = "/sdk/rds/plat_rds_bind_shop/list" // 获取已绑定的 RDS 推送店铺列表
)

// uri & hdl 映射表
func GenRouteMap(hdl IHdl) map[string]interface{} {
	m := map[string]interface{}{}
	m[EURIAuthGetAuthAddr] = hdl.AuthLinkHdl()
	m[EURIAuthIsAuthorized] = hdl.IsAuthorizedHdl()
	m[EURIAuthTokenValid] = hdl.IsTokenValidHdl()
	m[EURIAuthValidateCode] = hdl.ValidateCodeHdl()

	m[EURIGoodsInfo] = hdl.GoodsInfoHdl()
	m[EURIGoodsCats] = hdl.GoodsCatsHdl()
	m[EURIGoodsList] = hdl.GoodsListHdl()
	m[EURIParseGoodsId] = hdl.ParseGoodsIdHdl()
	m[EURIGoodsDetailImg] = hdl.GoodsDetailImgHdl()

	m[EURIShopCategoryInfo] = hdl.GetShopCategoryHdl()
	m[EURIGetUserSubs] = hdl.GetUserSubsHdl()
	m[EURIGetUserDepartment] = hdl.GetUserDepartmentHdl()

	m[EURIGateProxy] = hdl.GateProxyHdl()
	m[EURITokenInfo] = hdl.GetTokenHdl()

	m[EURITradeInfo] = hdl.TradeInfoHdl()
	m[EURITradeList] = hdl.TradeListHdl()
	m[EURITradeLogisticsCategory] = hdl.TradeLogisticsCategoryHdl()
	m[EURITradeFullInfo] = hdl.TradeFullInfoHdl()

	m[EURILogisticsInfo] = hdl.LogisticsInfoHdl()

	m[EURIRefundInfo] = hdl.RefundInfoHdl()
	m[EURIRefundList] = hdl.RefundListHdl()

	m[EURIMarketOrderDetail] = hdl.MarketOrderInfoHdl()

	//one_id
	m[EURIOneIdSaveOneIDInfo] = hdl.SaveOneIDInfoHdl()
	m[EURIOneIdBuyerNickSave] = hdl.BuyerNickSaveHdl()
	m[EURIOneIdGetByBuyerNick] = hdl.GetByBuyerNickHdl()
	m[EURIOneIdGetByOpenUID] = hdl.GetByOpenUIDHdl()
	m[EURIOneIdBuyerNickGetByOneID] = hdl.BuyerNickGetByOneIDHdl()
	m[EURIOneIdCheckWhiteListShop] = hdl.CheckWhiteListShopHdl()
	m[EURIOneIdOpenUIDGetByOneID] = hdl.OpenUIDGetByOneIDHdl()
	m[EURIOneIdOpenUIDGetByNick] = hdl.OpenUIDGetByNickHdl()

	m[EURIOneIdGetBuyerNickByBuyerID] = hdl.GetBuyerNickByBuyerIDHdl()

	//
	m[EURIRdsAddShop] = hdl.RdsAddShopHdl()   // 添加 RDS 数据推送店铺
	m[EURIRdsDelShop] = hdl.RdsDelShopHdl()   // 删除 RDS 数据推送店铺
	m[EURIRdsListShop] = hdl.RdsListShopHdl() // 获取已绑定的 RDS 推送店铺列表

	return m
}

// 用户自定义API
type SpecAPI struct {
	URI string
	Hdl interface{}
	Opt []httpmiddles.Option
}

// 服务api路由设置
// Hdl              : sdk 通用api handler实现
// APIs             : 本服务(sdk-api、sdk-gate)提供的通用api,
// ReverseProxyAPIs : 透传到sdk-gate处理的请求
// SpecAPIs         : 自定义的api
type ApiSetter struct {
	Hdl              IHdl
	APIs             []string
	ReverseProxyAPIs []string
	SpecAPIs         []SpecAPI
}

type RouteRegFunc func(uri string, hdl interface{}, opt ...httpmiddles.Option)
type RouteProxyRegFunc func(uri string)

func RouteRegister(ctx context.Context, setter *ApiSetter, route RouteRegFunc, routeProxy RouteProxyRegFunc) {

	mark := map[string]bool{}

	mapHdl := GenRouteMap(setter.Hdl)

	// 通用API
	for _, v := range setter.APIs {
		h, ok := mapHdl[v]
		if !ok {
			panic("sdk common api route register failed: miss common hdl def, api: " + v)
		}
		route(v, h)
		mark[v] = true
		logger.Infof(ctx, "reg common api: %s", v)
	}

	// 自定义API
	for _, v := range setter.SpecAPIs {
		route(v.URI, v.Hdl, v.Opt...)
		mark[v.URI] = true
		logger.Infof(ctx, "reg special api: %s", v.URI)
	}

	// 透传
	for _, v := range setter.ReverseProxyAPIs {
		routeProxy(v)
		mark[v] = true
		logger.Infof(ctx, "reg reverse proxy api: %s", v)
	}

	// 注册默认实现，友好返回该服务未实现接口
	for u, h := range mapHdl {
		if _, ok := mark[u]; ok {
			continue
		}
		route(u, h)
		logger.Infof(ctx, "reg unknown api: %s", u)
	}
}
