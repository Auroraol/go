package app

// 应用权限定义
// 根据sdk-tb功能点定义的， 划分是否合理需要确认

type TAppPri string

const (
	EPriShop             TAppPri = "pri.sdkapp.shop"
	EPriShopInfo                 = "pri.sdkapp.shop.info"
	EPriShopCats                 = "pri.sdkapp.shop.cats"
	EPriShopSellerCats           = "pri.sdkapp.shop.seller_cats"
	EPriShopIsAuthorized         = "pri.sdkapp.shop.is_authorized"

	EPriGoods                   = "pri.sdkapp.goods"
	EPriGoodsInfo               = "pri.sdkapp.goods.info"
	EPriGoodsBatchInfo          = "pri.sdkapp.goods.batch_info"
	EPriGoodsInventoryGoodsInfo = "pri.sdkapp.goods.inventory_goods_info"

	EPriGoodsOnsaleInfos   = "pri.sdkapp.goods.onsale_infos"
	EPriGoodsInventoryInfo = "pri.sdkapp.goods.inventory_info"

	EPriGoodsCatsInfo = "pri.sdkapp.goods.cats_info"

	EPriTrade              = "pri.sdkapp.trade"
	EPriTradeOrderFullInfo = "pri.sdkapp.trade.full_info"
	EPriTradeSoldGet       = "pri.sdkapp.trade.sold"
	EPriTradeIncrement     = "pri.sdkapp.trade.sold_increment"
	EPriTradeRate          = "pri.sdkapp.trade.rate"

	EPriTradeRefund = "pri.sdkapp.trade.refund"

	EPriLogistics     = "pri.sdkapp.logistics"
	EPriLogisticsInfo = "pri.sdkapp.logistics_info"

	EPriUser            = "pri.sdkapp.user"
	EPriUserSubs        = "pri.sdkapp.user.subs"
	EPriUserDepartments = "pri.sdkapp.user.departments"
	EPriUserSubInfo     = "pri.sdkapp.user.sub_info"

	EpriTmc            = "pri.sdkapp.tmc"
	EpriTmcPermit      = "pri.sdkapp.tmc.permit"
	EpriTmcCancel      = "pri.sdkapp.tmc.cancel"
	EpriTmcGroupAdd    = "pri.sdkapp.tmc.group.add"
	EpriTmcGroupDelete = "pri.sdkapp.tmc.group.delete"

	EpriMsgsync        = "pri.sdkapp.msgsync"
	EpriMsgsyncUserAdd = "pri.sdkapp.msgsync.user.add"
)
