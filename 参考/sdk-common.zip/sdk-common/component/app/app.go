package app

type IApp interface {
	Name() string
	SetName(name string) IApp
	SetPri(pris []TAppPri) IApp
	HasPrivilege(pri TAppPri) bool
	HasPrivileges(pris []TAppPri) bool
	Pickedup()
	PickedupTimes() int64
}
