package app

import (
	"math/rand"
)

// 多个app的匹配 & 轮询,提供了 random、roundrobin 两种方式

type TApps struct {
	Apps []IApp
}

func (apps *TApps) AddApp(app IApp) {
	apps.Apps = append(apps.Apps, app)
}

// 匹配具备指定权限的应用
func (apps *TApps) AppsMatch(pris []TAppPri) *TApps {
	newApps := &TApps{}
	for _, v := range apps.Apps {
		if v.HasPrivileges(pris) {
			newApps.Apps = append(newApps.Apps, v)
		}
	}
	return newApps
}

// 轮询获取一个应用
func (apps *TApps) PickupRoundrobin() IApp {
	if len(apps.Apps) == 0 {
		return nil
	}
	min := apps.Apps[0]
	for _, v := range apps.Apps {
		if v.PickedupTimes() < min.PickedupTimes() {
			min = v
		}
	}
	min.Pickedup()
	return min
}

// 随机获取一个应用
func (apps *TApps) PickupRandom() IApp {
	if len(apps.Apps) == 0 {
		return nil
	}
	idx := rand.Intn(len(apps.Apps))
	return apps.Apps[idx]
}
