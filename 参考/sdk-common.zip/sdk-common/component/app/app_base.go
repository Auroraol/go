package app

import (
	"sync/atomic"
)

// app权限管理部分的通用实现

type TAppBase struct {
	AppName       string
	calledTimes   int64
	Privileges    []TAppPri
	MapPrivileges map[TAppPri]bool
}

func (app *TAppBase) Name() string {
	return app.AppName
}

func (app *TAppBase) SetName(name string) IApp {
	app.AppName = name
	return app
}

func (app *TAppBase) SetPri(priList []TAppPri) IApp {
	app.Privileges = priList
	app.MapPrivileges = map[TAppPri]bool{}
	for _, v := range priList {
		app.MapPrivileges[v] = true
	}
	return app
}

func (app *TAppBase) HasPrivilege(pri TAppPri) bool {
	_, ok := app.MapPrivileges[pri]
	return ok
}

func (app *TAppBase) HasPrivileges(pris []TAppPri) bool {
	for _, pri := range pris {
		_, ok := app.MapPrivileges[pri]
		if !ok {
			return false
		}
	}
	return true
}

func (app *TAppBase) Pickedup() {
	atomic.AddInt64(&app.calledTimes, 1)
}

func (app *TAppBase) PickedupTimes() int64 {
	return app.calledTimes
}
