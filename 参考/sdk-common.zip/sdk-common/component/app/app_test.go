package app

import "testing"

type App1 struct {
	// some fileds
	// ...
	TAppBase
	// some fileds
	// ...
}

type App2 struct {
	// some fileds
	// ...
	TAppBase
	// some fileds
	// ...
}

type App3 struct {
	// some fileds
	// ...
	TAppBase
	// some fileds
	// ...
}

func TestAppPickup(t *testing.T) {
	// 假设有3个app, 并且设置了不同的权限
	app1 := (&App1{}).SetName("app1").SetPri([]TAppPri{EPriGoodsCatsInfo, EPriGoodsInfo})
	app2 := (&App2{}).SetName("app2").SetPri([]TAppPri{EPriShopInfo})
	app3 := (&App3{}).SetName("app3")

	// 用户授权了哪些应用
	authorizedApps := &TApps{}
	authorizedApps.AddApp(app1)
	authorizedApps.AddApp(app2)
	authorizedApps.AddApp(app3)

	// 挑选一个满足指定权限的应用
	pick := authorizedApps.AppsMatch([]TAppPri{EPriGoodsInfo}).PickupRoundrobin()
	if pick.Name() != "app1" {
		t.Errorf("match pris failed")
	}

	app3.SetPri([]TAppPri{EPriGoodsInfo})
	pick = authorizedApps.AppsMatch([]TAppPri{EPriGoodsInfo}).PickupRoundrobin()
	if pick.Name() != "app3" {
		t.Errorf("strategy roundrobin failed")
	}
}
