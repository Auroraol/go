package shop

import (
	"context"
	"time"

	"github.com/pkg/errors"

	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient/hooks"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
)

// fixme: 统一用user_service客户端 (但目前us 客户端不完善，不好用)
type Config struct {
	UserService string        `mapstructure:"user_service"`
	Timeout     time.Duration `mapstructure:"timeout"`
}

type Client struct {
	httpclient.Client
}

var _defaultClient *Client

func Init(conf *Config) {
	_defaultClient = NewClient(conf)
}

func NewClient(conf *Config) *Client {
	opts := []httpclient.Option{
		httpclient.WithAddress(conf.UserService),
		httpclient.WithTimeout(conf.Timeout * time.Second),
	}

	opts = append(opts, httpclient.WithPreRequestHooks(hooks.LoggingRequestWithLogger(logger.StandardLogger())))
	opts = append(opts, httpclient.WithAfterResponseHooks(hooks.LoggingResponseWithLogger(logger.StandardLogger())))

	c := &Client{}
	c.Client, _ = httpclient.NewClient(opts...)
	return c
}

func (c *Client) GetShopInfo(ctx context.Context, shopID string) (*TShop, error) {
	type GetShopInfoResponse struct {
		Shop *TShop `json:"shop"` // 店铺信息响应
	}
	rsp := &GetShopInfoResponse{}
	_, err := c.NewRequest(ctx).SetQueryParam("id", shopID).SetResult(rsp).Get("/internal/shop/info")

	if err != nil {
		return nil, errors.Wrap(err, "failed to get request")
	}
	return rsp.Shop, nil
}
