package shop

import (
	"time"

	"github.com/patrickmn/go-cache"
)

type ShopCache struct {
	c *cache.Cache
}

var defaultCache *ShopCache

func init() {
	defaultCache = &ShopCache{}
	defaultCache.c = cache.New(36*time.Hour, 1*time.Hour) // 用到的店铺信息不会改变，
}

func (m *ShopCache) Get(key string) *TShop {
	s, _ := m.c.Get(key)
	if s == nil {
		return nil
	}
	return s.(*TShop)
}

func (m *ShopCache) Set(key string, s *TShop) {
	m.c.Set(key, s, 0)
}
