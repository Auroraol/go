package shop

import (
	"context"
	"fmt"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"

	"github.com/pkg/errors"
)

// 目前的小平台sdk只用到了这些字段，需要其他字段的请自行添加
type TShop struct {
	PlatUserID   string `json:"plat_user_id"`   // 平台用户ID
	PlatShopType string `json:"plat_shop_type"` // 店铺类型
}

func GetShopByID(ctx context.Context, id string) (*TShop, error) {
	s := defaultCache.Get(id)
	if s != nil {
		return s, nil
	}
	var err error
	s, err = _defaultClient.GetShopInfo(ctx, id)
	if err == nil {
		defaultCache.Set(id, s)
	}
	return s, err
}

func TryGetPlatShopId(ctx context.Context, req proto.ShopBaseReq) (string, error) {
	if req.PlatShopId == "" && req.ShopId == "" && req.PlatUserId == "" {
		return "", errors.New("shop_id and user_name can not be all empty")
	}

	platShopId := ""
	if req.PlatShopId != "" {
		platShopId = req.PlatShopId
	} else if req.PlatUserId != "" {
		platShopId = req.PlatUserId
	}

	if platShopId == "" {
		// 从shop_id获取user_name
		shopInfo, err := GetShopByID(ctx, req.ShopId)
		if err != nil || shopInfo == nil {
			return "", errors.New(fmt.Sprintf("can not get plat_user_id(%s) by shop_id", req.ShopId))
		}
		return shopInfo.PlatUserID, nil
	} else {
		return platShopId, nil
	}
}
