package proxy

import (
	"context"
	"time"

	"github.com/pkg/errors"
	libapi "gitlab.xiaoduoai.com/ecrobot/sdk-common/component/api"
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"

	libtoken "gitlab.xiaoduoai.com/ecrobot/sdk-common/component/token"

	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient/hooks"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
)

type ApiProxy struct {
	appName string
	client  httpclient.Client
}

func NewApiProxy(conf ProxyConfig) (IProxy, error) {
	c := ApiProxy{
		appName: conf.AppName,
	}
	apiConf := conf.Api
	opts := []httpclient.Option{httpclient.WithTimeout(apiConf.Timeout * time.Second)}
	opts = append(opts, httpclient.WithAddress(apiConf.Url))
	opts = append(opts, httpclient.WithPreRequestHooks(hooks.LoggingRequestWithLogger(logger.StandardLogger())))
	opts = append(opts, httpclient.WithAfterResponseHooks(hooks.LoggingResponseWithLogger(logger.StandardLogger())))
	client, err := httpclient.NewClient(opts...)
	if err != nil {
		return nil, err
	}
	c.client = client
	return c, nil
}

func (p ApiProxy) GetToken(ctx context.Context, plat_shop_id string) (libtoken.IToken, error) {
	param := map[string]string{
		"plat_shop_id": plat_shop_id,
		"app_name":     p.appName,
	}
	res := &proto.GetTokenRspV2{}
	ret := &proto.SDKRsp{
		Data: res,
	}
	_, err := p.client.NewRequest(ctx).SetBody(param).SetResult(ret).Post(libapi.EURITokenInfo)
	if err != nil {
		return nil, errors.Wrap(err, "api get token err")
	}
	return res.Token, nil
}
