package proxy

import (
	"time"
)

const (
	API_METHOD   string = "api"
	REDIS_METHOD string = "redis"
)

type ProxyConfig struct {
	Method    string `mapstructure:"method"`
	AppName   string `mapstructure:"app_name"`
	IsDefault bool   `mapstructure:"is_default"`
	Api       Api    `mapstructure:"api_map"`
}

type Config struct {
	Proxys []ProxyConfig `mapstructure:"proxys"`
}
type Api struct {
	Url     string        `mapstructure:"url"`
	Timeout time.Duration `mapstructure:"time_out"`
}
