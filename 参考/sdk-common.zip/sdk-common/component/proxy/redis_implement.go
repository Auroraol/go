package proxy

import (
	"context"

	"github.com/pkg/errors"

	libtoken "gitlab.xiaoduoai.com/ecrobot/sdk-common/component/token"
)

type RedisProxy struct {
	appName string
}

func NewRedisProxy(conf ProxyConfig) (IProxy, error) {
	return RedisProxy{
		appName: conf.AppName,
	}, nil
}

func (p RedisProxy) GetToken(ctx context.Context, plat_shop_id string) (libtoken.IToken, error) {
	t, err := libtoken.GetMgrInstance(p.appName).LoadToken(ctx, plat_shop_id)
	if err != nil {
		return nil, errors.Wrap(err, "redis load token err")
	}
	return t, nil
}
