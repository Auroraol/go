package proxy

import (
	"context"
	"fmt"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/token"
)

var DefaultAppName = "default"

type IProxy interface {
	GetToken(ctx context.Context, plat_shop_id string) (token.IToken, error)
}

var proxyInstances map[string]IProxy

func GetInstance(appName string) IProxy {
	if appName == "" {
		appName = DefaultAppName
	}
	proxy, ok := proxyInstances[appName]
	if !ok {
		return nil
	}
	return proxy
}

func InitProxys(conf Config) error {
	for _, proxyConf := range conf.Proxys {
		if proxyConf.AppName == "" {
			panic("appname is request not nil")
		}
		iproxy, err := New(proxyConf)
		if err != nil {
			return err
		}
		err = RegisterProxy(proxyConf.AppName, iproxy)
		if err != nil {
			return err
		}
		if proxyConf.IsDefault {
			err = RegisterProxy(DefaultAppName, iproxy)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func RegisterProxy(appName string, proxy IProxy) error {
	if proxyInstances == nil {
		proxyInstances = make(map[string]IProxy)
	}
	if _, ok := proxyInstances[appName]; ok {
		return fmt.Errorf("proxy %s already exist", appName)
	}
	proxyInstances[appName] = proxy
	return nil
}

func New(conf ProxyConfig) (IProxy, error) {
	switch conf.Method {
	case REDIS_METHOD:
		return NewRedisProxy(conf)
	case API_METHOD:
		return NewApiProxy(conf)
	default:
		return NewApiProxy(conf)
	}
}
