package multi_platform_client

import "time"

type ClientConfig struct {
	Platform string        `mapstructure:"platform"`
	Url      string        `mapstructure:"url"`
	Timeout  time.Duration `mapstructure:"timeout"`
}

type Config struct {
	MultiPlatformConfig []ClientConfig `mapstructure:"multi_platform_client"`
}
