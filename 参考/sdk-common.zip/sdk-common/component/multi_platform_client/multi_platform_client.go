package multi_platform_client

import (
	"context"
	"time"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/client"
	"gitlab.xiaoduoai.com/golib/xd_sdk/logger"
)

var _gMultiPlatformClient map[string]*client.SdkClientBase

func Init(conf Config) {
	ctx := context.Background()
	multiPlatformClient := map[string]*client.SdkClientBase{}
	for _, c := range conf.MultiPlatformConfig {
		singleClient, err := client.InitClient(c.Url, c.Timeout)
		if err != nil {
			logger.Warningf(ctx, "%s platform init client error %+v", c.Platform, err)
			continue
		}
		multiPlatformClient[c.Platform] = singleClient
	}
	_gMultiPlatformClient = multiPlatformClient
}

func SinglePlatformInit(ctx context.Context, platform, host string, timeout time.Duration) error {
	if _gMultiPlatformClient == nil {
		_gMultiPlatformClient = map[string]*client.SdkClientBase{}
	}
	singleClient, err := client.InitClient(host, timeout)
	if err != nil {
		logger.Warningf(ctx, "%s platform init client error %+v", platform, err)
		return err
	}
	_gMultiPlatformClient[platform] = singleClient
	return nil
}

func API(platform string) (client.IAPI, bool) {
	c, ok := _gMultiPlatformClient[platform]
	if ok {
		return c, ok
	}
	return nil, false
}
