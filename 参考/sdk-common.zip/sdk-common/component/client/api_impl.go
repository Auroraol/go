package client

import (
	"context"
	"fmt"
	"time"

	"gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/component/api"
	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient"
	"gitlab.xiaoduoai.com/golib/xd_sdk/httpclient/hooks"
)

func InitClient(host string, timeoutSec time.Duration) (*SdkClientBase, error) {
	c, err := httpclient.NewClient(
		httpclient.WithAddress(host),
		httpclient.WithTimeout(timeoutSec*time.Second),
		httpclient.WithPreRequestHooks(hooks.LoggingRequest()),
		httpclient.WithAfterResponseHooks(hooks.LoggingResponse()),
		httpclient.WithParseSvcCodeFuncs(parseSvcCode),
	)
	if err != nil {
		return nil, err
	}
	return &SdkClientBase{Client: c}, nil
}

func parseSvcCode(httpCode int, body interface{}) (svcCode int, ok bool) {
	switch httpCode {
	case 200, 400, 401, 403:
		switch v := body.(type) {
		case *httpRspData:
			return v.Code, true
		default:
		}
	default:
	}
	return
}

func Init(host string, timeoutSec int) error {
	clientBase, err := InitClient(host, time.Duration(timeoutSec))
	if err != nil {
		return err
	}
	SetAPI(clientBase)
	SetSpecialApi(&SpecialClientBase{SdkClientBase: clientBase})
	return nil
}

type httpRspData struct {
	Code int         `json:"code"`
	Msg  interface{} `json:"message"`
	Data interface{} `json:"data"`
}

type SdkClientBase struct {
	Client httpclient.Client
}

type SpecialClientBase struct {
	*SdkClientBase
}

func (c *SdkClientBase) doRequest(ctx context.Context, path string, req, rsp interface{}) *xd_error.XDError {
	ret := &httpRspData{Data: rsp}
	getResp, err := c.Client.NewRequest(ctx).SetBody(req).SetResult(ret).Post(path)
	if err != nil {
		return &xd_error.XDError{Code: xd_error.ErrorCodeSystem, Message: err.Error()}
	}

	if !getResp.IsSuccess() {
		return &xd_error.XDError{Code: xd_error.ErrorCodeSystem, Message: "check getResp.IsSuccess() failed"}
	}

	ret = getResp.Result().(*httpRspData)
	if ret.Code != int(xd_error.ErrorCodeOK) {
		return &xd_error.XDError{Code: xd_error.ErrorCodeType(ret.Code), Message: fmt.Sprintf("api err %v", ret)}
	}
	return nil
}

// rsp must be a pointer to a struct.
func (c *SpecialClientBase) Request(ctx context.Context, req, rsp interface{}, path string) error {
	if err := c.SdkClientBase.doRequest(ctx, path, req, rsp); err != nil {
		return err
	}
	return nil
}
func (c *SdkClientBase) GetGoodsInfo(ctx context.Context, req *proto.GetGoodsInfoReq) (*proto.GetGoodsInfoRsp, error) {
	var rsp proto.GetGoodsInfoRsp
	if err := c.doRequest(ctx, api.EURIGoodsInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetGoodsDetailImgs(ctx context.Context, req *proto.GetGoodsDetailImgReq) (*proto.GetGoodsDetailImgRsp, error) {
	var rsp proto.GetGoodsDetailImgRsp
	if err := c.doRequest(ctx, api.EURIGoodsDetailImg, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetGoodsList(ctx context.Context, req *proto.GetGoodsListReq) (*proto.GetGoodsListRsp, error) {
	var rsp proto.GetGoodsListRsp
	if err := c.doRequest(ctx, api.EURIGoodsList, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetGoodsCategoryInfo(ctx context.Context, req *proto.GetGoodsCategoryInfoReq) (*proto.GetGoodsCategoryInfoRsp, error) {
	var rsp proto.GetGoodsCategoryInfoRsp
	if err := c.doRequest(ctx, api.EURIGoodsCats, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) ParseGoodsLink(ctx context.Context, req *proto.ParseGoodsIdReq) (*proto.ParseGoodsIdRsp, error) {
	var rsp proto.ParseGoodsIdRsp
	if err := c.doRequest(ctx, api.EURIParseGoodsId, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetAuthLink(ctx context.Context, req *proto.GetAuthLinkReq) (*proto.GetAuthLinkRsp, error) {
	var rsp proto.GetAuthLinkRsp
	if err := c.doRequest(ctx, api.EURIAuthGetAuthAddr, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) IsAuthorized(ctx context.Context, req *proto.IsAuthorizedReq) (*proto.IsAuthorizedRsp, error) {
	var rsp proto.IsAuthorizedRsp
	if err := c.doRequest(ctx, api.EURIAuthIsAuthorized, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) IsTokenValid(ctx context.Context, req *proto.TokenValidReq) (*proto.TokenValidRsp, error) {
	var rsp proto.TokenValidRsp
	if err := c.doRequest(ctx, api.EURIAuthTokenValid, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) ValidateAuthCode(ctx context.Context, req *proto.ValidateCodeReq) (*proto.ValidateCodeRsp, error) {
	var rsp proto.ValidateCodeRsp
	if err := c.doRequest(ctx, api.EURIAuthValidateCode, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetShopCategoryInfo(ctx context.Context, req *proto.GetShopCategoryInfoReq) (*proto.GetShopCategoryInfoRsp, error) {
	var rsp proto.GetShopCategoryInfoRsp
	if err := c.doRequest(ctx, api.EURIShopCategoryInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetTradeInfo(ctx context.Context, req *proto.TradeInfoReq) (*proto.TradeInfoRsp, error) {
	rsp := proto.TradeInfoRsp{}
	if err := c.doRequest(ctx, api.EURITradeInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetTradeList(ctx context.Context, req *proto.TradeListReq) (*proto.TradeListRsp, error) {
	var rsp proto.TradeListRsp
	if err := c.doRequest(ctx, api.EURITradeList, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetTradeLogisticsCategory(ctx context.Context, req *proto.TradeLogisticsCategoryReq) (*proto.TradeLogisticsCategoryRsp, error) {
	var rsp proto.TradeLogisticsCategoryRsp
	if err := c.doRequest(ctx, api.EURITradeLogisticsCategory, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetTradeFullInfo(ctx context.Context, req *proto.TradeFullInfoReq) (*proto.TradeFullInfoRsp, error) {
	var rsp proto.TradeFullInfoRsp
	if err := c.doRequest(ctx, api.EURITradeFullInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetLogisticsInfo(ctx context.Context, req *proto.LogisticsInfoReq) (*proto.LogisticsInfoRsp, error) {
	var rsp proto.LogisticsInfoRsp
	if err := c.doRequest(ctx, api.EURILogisticsInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetMarketOrderInfo(ctx context.Context, req *proto.MarketOrderInfoReq) (*proto.MarketOrderInfoRsp, error) {
	var rsp proto.MarketOrderInfoRsp
	if err := c.doRequest(ctx, api.EURIMarketOrderDetail, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetTokenInfo(ctx context.Context, req *proto.GetTokenReq) (*proto.GetTokenRsp, error) {
	var rsp proto.GetTokenRsp
	if err := c.doRequest(ctx, api.EURITokenInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetUserSubs(ctx context.Context, req *proto.GetUserSubsReq) (*proto.GetUserSubsRes, error) {
	var rsp proto.GetUserSubsRes
	if err := c.doRequest(ctx, api.EURIGetUserSubs, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetUserDepartment(ctx context.Context, req *proto.GetUserDepartmentsReq) (*proto.GetUserDepartmentsRes, error) {
	var rsp proto.GetUserDepartmentsRes
	if err := c.doRequest(ctx, api.EURIGetUserDepartment, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}
func (c *SdkClientBase) GetRefundInfo(ctx context.Context, req *proto.RefundInfoReq) (*proto.RefundInfoRsp, error) {
	var rsp proto.RefundInfoRsp
	if err := c.doRequest(ctx, api.EURIRefundInfo, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}

func (c *SdkClientBase) GetRefundList(ctx context.Context, req *proto.RefundListReq) (*proto.RefundListRsp, error) {
	var rsp proto.RefundListRsp
	if err := c.doRequest(ctx, api.EURIRefundList, req, &rsp); err != nil {
		return nil, err
	}
	return &rsp, nil
}
