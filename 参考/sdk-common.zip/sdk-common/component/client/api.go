package client

import (
	"context"

	"gitlab.xiaoduoai.com/ecrobot/sdk-common/proto"
)

type IAPI interface {
	GetGoodsInfo(ctx context.Context, req *proto.GetGoodsInfoReq) (*proto.GetGoodsInfoRsp, error)
	GetGoodsDetailImgs(ctx context.Context, req *proto.GetGoodsDetailImgReq) (*proto.GetGoodsDetailImgRsp, error)
	ParseGoodsLink(ctx context.Context, req *proto.ParseGoodsIdReq) (*proto.ParseGoodsIdRsp, error)
	GetGoodsCategoryInfo(ctx context.Context, req *proto.GetGoodsCategoryInfoReq) (*proto.GetGoodsCategoryInfoRsp, error)
	GetGoodsList(ctx context.Context, req *proto.GetGoodsListReq) (*proto.GetGoodsListRsp, error)
	GetAuthLink(ctx context.Context, req *proto.GetAuthLinkReq) (*proto.GetAuthLinkRsp, error)
	IsAuthorized(ctx context.Context, req *proto.IsAuthorizedReq) (*proto.IsAuthorizedRsp, error)
	IsTokenValid(ctx context.Context, req *proto.TokenValidReq) (*proto.TokenValidRsp, error)
	ValidateAuthCode(ctx context.Context, req *proto.ValidateCodeReq) (*proto.ValidateCodeRsp, error)
	GetShopCategoryInfo(ctx context.Context, req *proto.GetShopCategoryInfoReq) (*proto.GetShopCategoryInfoRsp, error)
	GetTradeInfo(ctx context.Context, req *proto.TradeInfoReq) (*proto.TradeInfoRsp, error)
	GetTradeList(ctx context.Context, req *proto.TradeListReq) (*proto.TradeListRsp, error)
	GetTradeLogisticsCategory(ctx context.Context, req *proto.TradeLogisticsCategoryReq) (*proto.TradeLogisticsCategoryRsp, error)
	GetTradeFullInfo(ctx context.Context, req *proto.TradeFullInfoReq) (*proto.TradeFullInfoRsp, error)
	GetLogisticsInfo(ctx context.Context, req *proto.LogisticsInfoReq) (*proto.LogisticsInfoRsp, error)
	GetMarketOrderInfo(ctx context.Context, req *proto.MarketOrderInfoReq) (*proto.MarketOrderInfoRsp, error)
	GetUserSubs(ctx context.Context, req *proto.GetUserSubsReq) (*proto.GetUserSubsRes, error)
	GetUserDepartment(ctx context.Context, req *proto.GetUserDepartmentsReq) (*proto.GetUserDepartmentsRes, error)
	GetRefundInfo(ctx context.Context, req *proto.RefundInfoReq) (*proto.RefundInfoRsp, error)
	GetRefundList(ctx context.Context, req *proto.RefundListReq) (*proto.RefundListRsp, error)
}

// 用于请求哪些非common，各个平台sdk特有的方法，无需定义在IAPI里面的方法
type SpecialApi interface {
	Request(ctx context.Context, req, rsp interface{}, path string) error
}

var _APIInstance IAPI
var _SpecialApi SpecialApi

func API() IAPI {
	return _APIInstance
}

func SetAPI(api IAPI) {
	_APIInstance = api
}
func GetSpecialApi() SpecialApi {
	return _SpecialApi
}
func SetSpecialApi(sapi SpecialApi) {
	_SpecialApi = sapi
}
