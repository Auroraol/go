package proto

import "gitlab.xiaoduoai.com/golib/xd_sdk/xd_error"

type SDKRsp struct {
	xd_error.XDError
	Data interface{} `json:"data"`
}

type ShopBaseReq struct {
	PlatShopId string `json:"plat_shop_id" form:"plat_shop_id"`
	PlatUserId string `json:"plat_user_id" form:"plat_user_id"`
	ShopId     string `json:"shop_id" form:"shop_id"`
}

type CommonBaseReq struct {
	AppName string `json:"app_name" form:"app_name"`
}
