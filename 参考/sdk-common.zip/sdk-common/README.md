

### 背景  

目前平台sdk适配开发，不规范，从最开始的sdk-tb, 到sdk-jd、sdk-pdd，再到目前的sdk-sn（苏宁）、sdk-ks（快手），都是拷贝老的sdk代码然后来开发新的平台sdk, 代码复用性差，严重缺乏设计，也导致对接平台效率不高。  

然而上面的问题，不是最主要的问题。目前面临的核心问题是各个平台sdk的接口存在平台差异，没有按内部标准进行适配，导致平台差异浸入到系统内部... 造成的直接后果是很多内部本来可以通用的逻辑变得不通用，每接入一个平台，很多功能的补齐都要改一波内部代码，这显然不合理。

### 什么是 sdk-common  

sdk-common提供一个基础框架来支撑各个平台sdk的快速开发。它提供了什么功能：  
- 统一sdk通用api（路径、输入、输出、错误码）
- 提供默认api实现
- 提供基础的服务运行框架
- 提供统一的店铺查询缓存
- 提供统一的token管理模块
- 

##### 目录结构  


```
├── component
│   ├── api        // sdk api 定义
│   ├── app        // 平台应用
│   ├── client     // sdk 客户端
│   ├── multi_platform_client     // 多平台共存的sdk客户端
│   ├── sdkserver  // sdk 服务框架
│   ├── shop       // 店铺缓存
│   ├── proxy       // 用来处理测服和正式的跨环境数据
│   |── token      // token 管理器
│   └── id_map      // open_id和plat_shop_id的管理器（目前要求必须有open_id，plat_shop_id会新增）
├── proto          // sdk对内协议定义    

```


### 怎么基于 sdk-common 开发一个新平台的sdk (sdk-api、sdk-gate)

参考基于sdk-common改造的 sdk-sn-api、sdk-sn-gate  (branch v2)  


---

## 淘宝应用权限包整理
https://doc.xiaoduoai.com/pages/viewpage.action?pageId=267819623
